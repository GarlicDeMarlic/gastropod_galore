/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.gastropodgalore.GastropodGaloreMod;

@EventBusSubscriber
public class GastropodGaloreModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GastropodGaloreMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(GastropodGaloreModItems.ROASTED_CARROT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(GastropodGaloreModItems.SNAIL_SPAWN_EGG.get());
			tabData.accept(GastropodGaloreModItems.SLUG_SPAWN_EGG.get());
			tabData.accept(GastropodGaloreModItems.BANANA_SLUG_SPAWN_EGG.get());
			tabData.accept(GastropodGaloreModItems.APPLE_SNAIL_SPAWN_EGG.get());
			tabData.accept(GastropodGaloreModItems.SEA_BUNNY_SPAWN_EGG.get());
			tabData.accept(GastropodGaloreModItems.MAGMA_SNAIL_SPAWN_EGG.get());
			tabData.accept(GastropodGaloreModItems.VOLCANIC_SNAIL_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(GastropodGaloreModItems.SNAIL_SHELL.get());
			tabData.accept(GastropodGaloreModItems.VOLCANIC_SNAIL_SHELL.get());
		}
	}
}