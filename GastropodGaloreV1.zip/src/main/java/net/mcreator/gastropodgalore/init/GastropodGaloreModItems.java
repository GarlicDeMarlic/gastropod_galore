/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;

import net.mcreator.gastropodgalore.item.VolcanicSnailShellItem;
import net.mcreator.gastropodgalore.item.SnailShellItem;
import net.mcreator.gastropodgalore.item.RoastedCarrotItem;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

import java.util.function.Function;

public class GastropodGaloreModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GastropodGaloreMod.MODID);
	public static final DeferredItem<Item> SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> BANANA_SLUG_SPAWN_EGG;
	public static final DeferredItem<Item> SLUG_SPAWN_EGG;
	public static final DeferredItem<Item> APPLE_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> VOLCANIC_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> MAGMA_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> SEA_BUNNY_SPAWN_EGG;
	public static final DeferredItem<Item> VOLCANIC_SNAIL_SHELL;
	public static final DeferredItem<Item> SNAIL_SHELL;
	public static final DeferredItem<Item> ROASTED_CARROT;
	static {
		SNAIL_SPAWN_EGG = register("snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.SNAIL.get(), properties));
		BANANA_SLUG_SPAWN_EGG = register("banana_slug_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.BANANA_SLUG.get(), properties));
		SLUG_SPAWN_EGG = register("slug_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.SLUG.get(), properties));
		APPLE_SNAIL_SPAWN_EGG = register("apple_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.APPLE_SNAIL.get(), properties));
		VOLCANIC_SNAIL_SPAWN_EGG = register("volcanic_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.VOLCANIC_SNAIL.get(), properties));
		MAGMA_SNAIL_SPAWN_EGG = register("magma_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.MAGMA_SNAIL.get(), properties));
		SEA_BUNNY_SPAWN_EGG = register("sea_bunny_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.SEA_BUNNY.get(), properties));
		VOLCANIC_SNAIL_SHELL = register("volcanic_snail_shell", VolcanicSnailShellItem::new);
		SNAIL_SHELL = register("snail_shell", SnailShellItem::new);
		ROASTED_CARROT = register("roasted_carrot", RoastedCarrotItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}
}