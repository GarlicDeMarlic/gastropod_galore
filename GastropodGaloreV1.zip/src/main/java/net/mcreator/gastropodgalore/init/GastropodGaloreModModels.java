/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.gastropodgalore.client.model.*;

@EventBusSubscriber(Dist.CLIENT)
public class GastropodGaloreModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modeldynamite_entity.LAYER_LOCATION, Modeldynamite_entity::createBodyLayer);
		event.registerLayerDefinition(Modelcrop_scattering_capsule.LAYER_LOCATION, Modelcrop_scattering_capsule::createBodyLayer);
		event.registerLayerDefinition(Modelslog.LAYER_LOCATION, Modelslog::createBodyLayer);
		event.registerLayerDefinition(Modellava_goop.LAYER_LOCATION, Modellava_goop::createBodyLayer);
		event.registerLayerDefinition(Modelghost_snail.LAYER_LOCATION, Modelghost_snail::createBodyLayer);
		event.registerLayerDefinition(Modelsea_bunny.LAYER_LOCATION, Modelsea_bunny::createBodyLayer);
		event.registerLayerDefinition(Modelbanana_slug.LAYER_LOCATION, Modelbanana_slug::createBodyLayer);
		event.registerLayerDefinition(Modelslug.LAYER_LOCATION, Modelslug::createBodyLayer);
		event.registerLayerDefinition(Modelapple_snail.LAYER_LOCATION, Modelapple_snail::createBodyLayer);
		event.registerLayerDefinition(Modelsnail.LAYER_LOCATION, Modelsnail::createBodyLayer);
		event.registerLayerDefinition(Modelvolcano_snail.LAYER_LOCATION, Modelvolcano_snail::createBodyLayer);
	}
}