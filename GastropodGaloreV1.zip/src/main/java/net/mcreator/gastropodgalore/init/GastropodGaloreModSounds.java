/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.gastropodgalore.GastropodGaloreMod;

public class GastropodGaloreModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, GastropodGaloreMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> SNAIL_HURT = REGISTRY.register("snail_hurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "snail_hurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SNAIL_DIES = REGISTRY.register("snail_dies", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "snail_dies")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DYNAMITE_THROW = REGISTRY.register("dynamite_throw", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "dynamite_throw")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SLUG_HURT = REGISTRY.register("slug_hurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "slug_hurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SLUG_DIES = REGISTRY.register("slug_dies", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "slug_dies")));
	public static final DeferredHolder<SoundEvent, SoundEvent> VOLCANIC_SNAIL_HURT = REGISTRY.register("volcanic_snail_hurt",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "volcanic_snail_hurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> VOLCANIC_SNAIL_DIES = REGISTRY.register("volcanic_snail_dies",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "volcanic_snail_dies")));
	public static final DeferredHolder<SoundEvent, SoundEvent> VOLCANIC_SNAIL_RUMBLE = REGISTRY.register("volcanic_snail_rumble",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "volcanic_snail_rumble")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MAGMA_SNAIL_HURT = REGISTRY.register("magma_snail_hurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "magma_snail_hurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MAGMA_SNAIL_DIES = REGISTRY.register("magma_snail_dies", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "magma_snail_dies")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MAGMA_SNAIL_RUMBLES = REGISTRY.register("magma_snail_rumbles",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "magma_snail_rumbles")));
	public static final DeferredHolder<SoundEvent, SoundEvent> VOLCANIC_SNAIL_RUMBLES = REGISTRY.register("volcanic_snail_rumbles",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "volcanic_snail_rumbles")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HAUNT_HURTS = REGISTRY.register("haunt_hurts", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "haunt_hurts")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HAUNT_DIES = REGISTRY.register("haunt_dies", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "haunt_dies")));
}