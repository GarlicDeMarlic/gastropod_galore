/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.gastropodgalore.client.renderer.*;

@EventBusSubscriber(Dist.CLIENT)
public class GastropodGaloreModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(GastropodGaloreModEntities.SNAIL.get(), SnailRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.BANANA_SLUG.get(), BananaSlugRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.SLUG.get(), SlugRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.APPLE_SNAIL.get(), AppleSnailRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.VOLCANIC_SNAIL.get(), VolcanicSnailRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.LAVA_GOOP.get(), LavaGoopRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.MAGMA_GOOP.get(), MagmaGoopRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.MAGMA_SNAIL.get(), MagmaSnailRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.SEA_BUNNY.get(), SeaBunnyRenderer::new);
		event.registerEntityRenderer(GastropodGaloreModEntities.IMMORTAL_SNAIL.get(), ImmortalSnailRenderer::new);
	}
}