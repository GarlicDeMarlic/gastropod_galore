package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.VolcanicSnailEntity;
import net.mcreator.gastropodgalore.entity.SnailEntity;

import java.util.Comparator;

public class VolcanicSnailOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("croppy", 0);
		if (!(entity instanceof LivingEntity _livEnt1 && _livEnt1.isBaby())) {
			if (Math.random() < 0.6) {
				if (entity instanceof VolcanicSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(VolcanicSnailEntity.DATA_lava_cracks, 0);
			} else {
				if (entity instanceof VolcanicSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(VolcanicSnailEntity.DATA_lava_cracks, 1);
			}
		} else {
			{
				final Vec3 _center = new Vec3((entity.getX()), (entity.getY()), (entity.getZ()));
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof SnailEntity && entity instanceof LivingEntity _livEnt8 && _livEnt8.isBaby()) {
						if (entity instanceof VolcanicSnailEntity _datEntSetI)
							_datEntSetI.getEntityData().set(VolcanicSnailEntity.DATA_lava_cracks, 1);
					} else {
						if (Math.random() < 0.6) {
							if (entity instanceof VolcanicSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(VolcanicSnailEntity.DATA_lava_cracks, 0);
						} else {
							if (entity instanceof VolcanicSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(VolcanicSnailEntity.DATA_lava_cracks, 1);
						}
					}
				}
			}
		}
	}
}