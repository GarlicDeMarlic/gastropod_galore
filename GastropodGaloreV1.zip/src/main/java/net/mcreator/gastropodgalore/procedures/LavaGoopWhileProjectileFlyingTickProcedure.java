package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.init.GastropodGaloreModGameRules;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

public class LavaGoopWhileProjectileFlyingTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity immediatesourceentity) {
		if (immediatesourceentity == null)
			return;
		if ((world instanceof ServerLevel _serverLevelGR0 && _serverLevelGR0.getGameRules().getBoolean(GastropodGaloreModGameRules.VOLCANIC_HAVOC)) == true) {
			if (world instanceof ServerLevel _level)
				FallingBlockEntity.fall(_level, BlockPos.containing(x + Mth.nextDouble(RandomSource.create(), -3, 3), y + Mth.nextDouble(RandomSource.create(), 2, 3), z + Mth.nextDouble(RandomSource.create(), -3, 3)),
						Blocks.MAGMA_BLOCK.defaultBlockState());
			if (world instanceof ServerLevel _level)
				FallingBlockEntity.fall(_level, BlockPos.containing(x + Mth.nextDouble(RandomSource.create(), -3, 3), y + Mth.nextDouble(RandomSource.create(), 2, 3), z + Mth.nextDouble(RandomSource.create(), -3, 3)),
						Blocks.OBSIDIAN.defaultBlockState());
			if (world instanceof ServerLevel _level)
				FallingBlockEntity.fall(_level, BlockPos.containing(x + Mth.nextDouble(RandomSource.create(), -3, 3), y + Mth.nextDouble(RandomSource.create(), 2, 3), z + Mth.nextDouble(RandomSource.create(), -3, 3)),
						Blocks.OBSIDIAN.defaultBlockState());
			if (world instanceof ServerLevel _level)
				FallingBlockEntity.fall(_level, BlockPos.containing(x + Mth.nextDouble(RandomSource.create(), -3, 3), y + Mth.nextDouble(RandomSource.create(), 2, 3), z + Mth.nextDouble(RandomSource.create(), -3, 3)),
						Blocks.BLACKSTONE.defaultBlockState());
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 3, Level.ExplosionInteraction.BLOCK);
			GastropodGaloreMod.queueServerWork(20, () -> {
				if (!immediatesourceentity.level().isClientSide())
					immediatesourceentity.discard();
			});
		}
	}
}