package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

public class VolcanicSnailOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < 6; index0++) {
			sy = -3;
			for (int index1 = 0; index1 < 6; index1++) {
				sz = -3;
				for (int index2 = 0; index2 < 6; index2++) {
					if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.ICE || (world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.PACKED_ICE
							|| (world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.BLUE_ICE) {
						world.setBlock(BlockPos.containing(x + sx, y + sy, z + sz), Blocks.AIR.defaultBlockState(), 3);
						world.setBlock(BlockPos.containing(x + sx, y + sy, z + sz), Blocks.WATER.defaultBlockState(), 3);
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if ((entity.getPersistentData().getDoubleOr("smoke", 0) == 40 || entity.getPersistentData().getDoubleOr("smoke", 0) > 40) && !(entity instanceof Mob _mobEnt10 && _mobEnt10.isAggressive())) {
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.7, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.7, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			entity.getPersistentData().putDouble("smoke", 0);
		} else if (entity.getPersistentData().getDoubleOr("smoke", 0) >= 10 && entity instanceof Mob _mobEnt25 && _mobEnt25.isAggressive()) {
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)), 0.8, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)), 0.8, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)), 0.8, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)));
			world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			entity.getPersistentData().putDouble("smoke", 0);
		} else {
			entity.getPersistentData().putDouble("smoke", (entity.getPersistentData().getDoubleOr("smoke", 0) + 1));
		}
	}
}