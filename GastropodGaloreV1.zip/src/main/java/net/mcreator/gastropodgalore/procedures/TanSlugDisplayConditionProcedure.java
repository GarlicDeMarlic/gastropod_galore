package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.SlugEntity;

public class TanSlugDisplayConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_variant) : 0) == 0;
	}
}