package net.mcreator.gastropodgalore.item;

import net.minecraft.world.item.Item;

public class SnailShellItem extends Item {
	public SnailShellItem(Item.Properties properties) {
		super(properties);
	}
}