package net.mcreator.gastropodgalore.item;

import net.minecraft.world.item.Item;

public class VolcanicSnailShellItem extends Item {
	public VolcanicSnailShellItem(Item.Properties properties) {
		super(properties.fireResistant());
	}
}