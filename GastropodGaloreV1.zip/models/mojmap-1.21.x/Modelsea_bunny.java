// Made with Blockbench 5.0.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelsea_bunny<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "sea_bunny"), "main");
	private final ModelPart slug;
	private final ModelPart body;
	private final ModelPart eyes;
	private final ModelPart horn_ig_1;
	private final ModelPart horn_ig_2;
	private final ModelPart tail;

	public Modelsea_bunny(ModelPart root) {
		this.slug = root.getChild("slug");
		this.body = this.slug.getChild("body");
		this.eyes = this.body.getChild("eyes");
		this.horn_ig_1 = this.eyes.getChild("horn_ig_1");
		this.horn_ig_2 = this.eyes.getChild("horn_ig_2");
		this.tail = this.body.getChild("tail");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition slug = partdefinition.addOrReplaceChild("slug", CubeListBuilder.create(),
				PartPose.offset(0.0F, 24.0F, 2.5F));

		PartDefinition body = slug.addOrReplaceChild("body", CubeListBuilder.create().texOffs(6, 4).addBox(-2.11F,
				-3.0F, -5.78F, 4.0F, 3.0F, 7.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition eyes = body.addOrReplaceChild("eyes", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.3F, 0.0F));

		PartDefinition horn_ig_1 = eyes.addOrReplaceChild("horn_ig_1", CubeListBuilder.create(),
				PartPose.offset(-0.8246F, -3.4786F, -6.0107F));

		PartDefinition cube_r1 = horn_ig_1.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(1, 24).addBox(-2.0F, -4.0F, 0.0F, 3.0F, 5.0F, 0.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.4792F, 0.5152F, -0.4236F));

		PartDefinition horn_ig_2 = eyes.addOrReplaceChild("horn_ig_2", CubeListBuilder.create(),
				PartPose.offset(1.4246F, -3.1786F, -5.5107F));

		PartDefinition cube_r2 = horn_ig_2.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(1, 24).mirror()
				.addBox(-1.8296F, -4.0722F, -0.0807F, 3.0F, 5.0F, 0.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.4792F, -0.5152F, 0.4236F));

		PartDefinition tail = body.addOrReplaceChild("tail", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.25F, -2.4413F, 1.8214F, 0.5236F, 0.0F, 0.0F));

		PartDefinition cube_r3 = tail.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(13, 14).addBox(-1.5733F, -0.6807F, -0.0063F, 3.0F, 3.0F, 0.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.25F, -0.8651F, 1.3443F, -1.5632F, -0.0869F, 1.5708F));

		PartDefinition cube_r4 = tail.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(13, 14).addBox(-1.0F, -0.6808F, -0.5736F, 3.0F, 3.0F, 0.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.25F, -0.3651F, 1.3443F, -1.4835F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		slug.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}