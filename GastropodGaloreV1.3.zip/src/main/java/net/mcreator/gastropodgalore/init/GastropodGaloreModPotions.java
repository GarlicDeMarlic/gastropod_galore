/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.gastropodgalore.GastropodGaloreMod;

public class GastropodGaloreModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, GastropodGaloreMod.MODID);
	public static final DeferredHolder<Potion, Potion> SLUGGISHNESS = REGISTRY.register("sluggishness",
			() -> new Potion("sluggishness", new MobEffectInstance(MobEffects.SLOWNESS, 1200, 1, false, true), new MobEffectInstance(MobEffects.RESISTANCE, 1200, 1, false, true)));
}