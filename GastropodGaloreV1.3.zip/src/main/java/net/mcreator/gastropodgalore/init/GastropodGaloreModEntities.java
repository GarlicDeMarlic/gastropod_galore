/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.gastropodgalore.entity.*;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

@EventBusSubscriber
public class GastropodGaloreModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, GastropodGaloreMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<SnailEntity>> SNAIL = register("snail",
			EntityType.Builder.<SnailEntity>of(SnailEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 0.6f));
	public static final DeferredHolder<EntityType<?>, EntityType<BananaSlugEntity>> BANANA_SLUG = register("banana_slug",
			EntityType.Builder.<BananaSlugEntity>of(BananaSlugEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.7f, 0.4f));
	public static final DeferredHolder<EntityType<?>, EntityType<SlugEntity>> SLUG = register("slug",
			EntityType.Builder.<SlugEntity>of(SlugEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.5f, 0.3f));
	public static final DeferredHolder<EntityType<?>, EntityType<AppleSnailEntity>> APPLE_SNAIL = register("apple_snail",
			EntityType.Builder.<AppleSnailEntity>of(AppleSnailEntity::new, MobCategory.WATER_CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(640).setUpdateInterval(3)

					.sized(0.3f, 0.3f));
	public static final DeferredHolder<EntityType<?>, EntityType<VolcanicSnailEntity>> VOLCANIC_SNAIL = register("volcanic_snail",
			EntityType.Builder.<VolcanicSnailEntity>of(VolcanicSnailEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(1f, 1f));
	public static final DeferredHolder<EntityType<?>, EntityType<MagmaSnailEntity>> MAGMA_SNAIL = register("magma_snail",
			EntityType.Builder.<MagmaSnailEntity>of(MagmaSnailEntity::new, MobCategory.WATER_CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.7f, 0.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<SeaBunnyEntity>> SEA_BUNNY = register("sea_bunny",
			EntityType.Builder.<SeaBunnyEntity>of(SeaBunnyEntity::new, MobCategory.WATER_CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(640).setUpdateInterval(3)

					.sized(0.3f, 0.3f));
	public static final DeferredHolder<EntityType<?>, EntityType<ImmortalSnailEntity>> IMMORTAL_SNAIL = register("immortal_snail",
			EntityType.Builder.<ImmortalSnailEntity>of(ImmortalSnailEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(5002).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 0.6f));
	public static final DeferredHolder<EntityType<?>, EntityType<PaintedSnailEntity>> PAINTED_SNAIL = register("painted_snail",
			EntityType.Builder.<PaintedSnailEntity>of(PaintedSnailEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<MossySnailEntity>> MOSSY_SNAIL = register("mossy_snail",
			EntityType.Builder.<MossySnailEntity>of(MossySnailEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 0.6f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(GastropodGaloreMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		SnailEntity.init(event);
		BananaSlugEntity.init(event);
		SlugEntity.init(event);
		AppleSnailEntity.init(event);
		VolcanicSnailEntity.init(event);
		MagmaSnailEntity.init(event);
		SeaBunnyEntity.init(event);
		ImmortalSnailEntity.init(event);
		PaintedSnailEntity.init(event);
		MossySnailEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SNAIL.get(), SnailEntity.createAttributes().build());
		event.put(BANANA_SLUG.get(), BananaSlugEntity.createAttributes().build());
		event.put(SLUG.get(), SlugEntity.createAttributes().build());
		event.put(APPLE_SNAIL.get(), AppleSnailEntity.createAttributes().build());
		event.put(VOLCANIC_SNAIL.get(), VolcanicSnailEntity.createAttributes().build());
		event.put(MAGMA_SNAIL.get(), MagmaSnailEntity.createAttributes().build());
		event.put(SEA_BUNNY.get(), SeaBunnyEntity.createAttributes().build());
		event.put(IMMORTAL_SNAIL.get(), ImmortalSnailEntity.createAttributes().build());
		event.put(PAINTED_SNAIL.get(), PaintedSnailEntity.createAttributes().build());
		event.put(MOSSY_SNAIL.get(), MossySnailEntity.createAttributes().build());
	}
}