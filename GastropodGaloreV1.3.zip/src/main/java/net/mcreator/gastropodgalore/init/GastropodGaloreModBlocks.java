/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.gastropodgalore.block.*;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

import java.util.function.Function;

public class GastropodGaloreModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(GastropodGaloreMod.MODID);
	public static final DeferredBlock<Block> SNAIL_SHELL;
	public static final DeferredBlock<Block> VOLCANIC_SNAIL_SHELL;
	public static final DeferredBlock<Block> TERRARIUM;
	public static final DeferredBlock<Block> GARDEN_SNAIL_TERRARIUM;
	public static final DeferredBlock<Block> GARDEN_SNAIL_TERRARIUM_1;
	public static final DeferredBlock<Block> GARDEN_SNAIL_TERRARIUM_2;
	public static final DeferredBlock<Block> GARDEN_SNAIL_TERRARIUM_3;
	public static final DeferredBlock<Block> APPLE_SNAIL_SHELL;
	public static final DeferredBlock<Block> MOSSY_SNAIL_SHELL_BROWN;
	public static final DeferredBlock<Block> MOSSY_SNAIL_SHELL_RED;
	public static final DeferredBlock<Block> MOSSY_SNAIL_SHELL_GREEN;
	public static final DeferredBlock<Block> MOSSY_SNAIL_SHELL_YELLOW;
	public static final DeferredBlock<Block> SLUG_TERRARIUM;
	public static final DeferredBlock<Block> SLUG_TERRARIUM_1;
	public static final DeferredBlock<Block> SLUG_TERRARIUM_2;
	public static final DeferredBlock<Block> SLUG_TERRARIUM_3;
	public static final DeferredBlock<Block> BANANA_SLUG_TERRARIUM;
	static {
		SNAIL_SHELL = register("snail_shell", SnailShellBlock::new);
		VOLCANIC_SNAIL_SHELL = register("volcanic_snail_shell", VolcanicSnailShellBlock::new);
		TERRARIUM = register("terrarium", TerrariumBlock::new);
		GARDEN_SNAIL_TERRARIUM = register("garden_snail_terrarium", GardenSnailTerrariumBlock::new);
		GARDEN_SNAIL_TERRARIUM_1 = register("garden_snail_terrarium_1", GardenSnailTerrarium1Block::new);
		GARDEN_SNAIL_TERRARIUM_2 = register("garden_snail_terrarium_2", GardenSnailTerrarium2Block::new);
		GARDEN_SNAIL_TERRARIUM_3 = register("garden_snail_terrarium_3", GardenSnailTerrarium3Block::new);
		APPLE_SNAIL_SHELL = register("apple_snail_shell", AppleSnailShellBlock::new);
		MOSSY_SNAIL_SHELL_BROWN = register("mossy_snail_shell_brown", MossySnailShellBlock::new);
		MOSSY_SNAIL_SHELL_RED = register("mossy_snail_shell_red", MossySnailShell1Block::new);
		MOSSY_SNAIL_SHELL_GREEN = register("mossy_snail_shell_green", MossySnailShell2Block::new);
		MOSSY_SNAIL_SHELL_YELLOW = register("mossy_snail_shell_yellow", MossySnailShell3Block::new);
		SLUG_TERRARIUM = register("slug_terrarium", SlugTerrariumBlock::new);
		SLUG_TERRARIUM_1 = register("slug_terrarium_1", SlugTerrarium1Block::new);
		SLUG_TERRARIUM_2 = register("slug_terrarium_2", SlugTerrarium2Block::new);
		SLUG_TERRARIUM_3 = register("slug_terrarium_3", SlugTerrarium3Block::new);
		BANANA_SLUG_TERRARIUM = register("banana_slug_terrarium", BananaSlugTerrariumBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}