/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.core.registries.Registries;

import net.mcreator.gastropodgalore.world.features.TemperateRainforestTreeFeature;
import net.mcreator.gastropodgalore.world.features.TemperateRainforestTree5Feature;
import net.mcreator.gastropodgalore.world.features.TemperateRainforestTree3Feature;
import net.mcreator.gastropodgalore.world.features.TemperateRainforestTree2Feature;
import net.mcreator.gastropodgalore.world.features.TemperateRainforestTree1Feature;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

public class GastropodGaloreModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(Registries.FEATURE, GastropodGaloreMod.MODID);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEMPERATE_RAINFOREST_TREE = REGISTRY.register("temperate_rainforest_tree", TemperateRainforestTreeFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEMPERATE_RAINFOREST_TREE_1 = REGISTRY.register("temperate_rainforest_tree_1", TemperateRainforestTree1Feature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEMPERATE_RAINFOREST_TREE_2 = REGISTRY.register("temperate_rainforest_tree_2", TemperateRainforestTree2Feature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEMPERATE_RAINFOREST_TREE_3 = REGISTRY.register("temperate_rainforest_tree_3", TemperateRainforestTree3Feature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEMPERATE_RAINFOREST_TREE_5 = REGISTRY.register("temperate_rainforest_tree_5", TemperateRainforestTree5Feature::new);
}