package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.init.GastropodGaloreModEntities;
import net.mcreator.gastropodgalore.init.GastropodGaloreModBlocks;
import net.mcreator.gastropodgalore.entity.SlugEntity;

import java.util.Comparator;

public class SlugTerrariumBlockIsPlacedByProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		{
			int _value = 1;
			BlockPos _pos = BlockPos.containing(x, y, z);
			BlockState _bs = world.getBlockState(_pos);
			if (_bs.getBlock().getStateDefinition().getProperty("blockstate") instanceof IntegerProperty _integerProp && _integerProp.getPossibleValues().contains(_value))
				world.setBlock(_pos, _bs.setValue(_integerProp, _value), 3);
		}
		if (!(((findEntityInWorldRange(world, SlugEntity.class, (x + 0.5), y, (z + 0.5), 1)) instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_terrarium) : 0) >= 1)) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GastropodGaloreModBlocks.SLUG_TERRARIUM_1.get()) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = GastropodGaloreModEntities.SLUG.get().spawn(_level, BlockPos.containing(x, y + 0.25, z), EntitySpawnReason.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				{
					final Vec3 _center = new Vec3((x + 0.5), (y + 0.25), (z + 0.5));
					for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(0.35 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
						if (entityiterator instanceof SlugEntity) {
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 1);
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_terrarium, 1);
							if (entityiterator instanceof LivingEntity _livingEntity9 && _livingEntity9.getAttributes().hasAttribute(Attributes.SCALE))
								_livingEntity9.getAttribute(Attributes.SCALE).setBaseValue(0.5);
							if (entityiterator instanceof LivingEntity _livingEntity10 && _livingEntity10.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
								_livingEntity10.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.005);
							if (entityiterator instanceof LivingEntity _livingEntity11 && _livingEntity11.getAttributes().hasAttribute(Attributes.JUMP_STRENGTH))
								_livingEntity11.getAttribute(Attributes.JUMP_STRENGTH).setBaseValue(0);
							{
								Entity _ent = entityiterator;
								_ent.teleportTo((x + 0.5), (y + 0.25), (z + 0.5));
								if (_ent instanceof ServerPlayer _serverPlayer)
									_serverPlayer.connection.teleport((x + 0.5), (y + 0.25), (z + 0.5), _ent.getYRot(), _ent.getXRot());
							}
						}
					}
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GastropodGaloreModBlocks.SLUG_TERRARIUM_2.get()) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = GastropodGaloreModEntities.SLUG.get().spawn(_level, BlockPos.containing(x, y + 0.25, z), EntitySpawnReason.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				{
					final Vec3 _center = new Vec3((x + 0.5), (y + 0.25), (z + 0.5));
					for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(0.35 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
						if (entityiterator instanceof SlugEntity) {
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 2);
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_terrarium, 1);
							if (entityiterator instanceof LivingEntity _livingEntity20 && _livingEntity20.getAttributes().hasAttribute(Attributes.SCALE))
								_livingEntity20.getAttribute(Attributes.SCALE).setBaseValue(0.5);
							if (entityiterator instanceof LivingEntity _livingEntity21 && _livingEntity21.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
								_livingEntity21.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.005);
							if (entityiterator instanceof LivingEntity _livingEntity22 && _livingEntity22.getAttributes().hasAttribute(Attributes.JUMP_STRENGTH))
								_livingEntity22.getAttribute(Attributes.JUMP_STRENGTH).setBaseValue(0);
							{
								Entity _ent = entityiterator;
								_ent.teleportTo((x + 0.5), (y + 0.25), (z + 0.5));
								if (_ent instanceof ServerPlayer _serverPlayer)
									_serverPlayer.connection.teleport((x + 0.5), (y + 0.25), (z + 0.5), _ent.getYRot(), _ent.getXRot());
							}
						}
					}
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GastropodGaloreModBlocks.SLUG_TERRARIUM_3.get()) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = GastropodGaloreModEntities.SLUG.get().spawn(_level, BlockPos.containing(x, y + 0.25, z), EntitySpawnReason.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				{
					final Vec3 _center = new Vec3((x + 0.5), (y + 0.25), (z + 0.5));
					for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(0.35 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
						if (entityiterator instanceof SlugEntity) {
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 3);
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_terrarium, 1);
							if (entityiterator instanceof LivingEntity _livingEntity31 && _livingEntity31.getAttributes().hasAttribute(Attributes.SCALE))
								_livingEntity31.getAttribute(Attributes.SCALE).setBaseValue(0.5);
							if (entityiterator instanceof LivingEntity _livingEntity32 && _livingEntity32.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
								_livingEntity32.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.005);
							if (entityiterator instanceof LivingEntity _livingEntity33 && _livingEntity33.getAttributes().hasAttribute(Attributes.JUMP_STRENGTH))
								_livingEntity33.getAttribute(Attributes.JUMP_STRENGTH).setBaseValue(0);
							{
								Entity _ent = entityiterator;
								_ent.teleportTo((x + 0.5), (y + 0.25), (z + 0.5));
								if (_ent instanceof ServerPlayer _serverPlayer)
									_serverPlayer.connection.teleport((x + 0.5), (y + 0.25), (z + 0.5), _ent.getYRot(), _ent.getXRot());
							}
						}
					}
				}
			} else {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = GastropodGaloreModEntities.SLUG.get().spawn(_level, BlockPos.containing(x, y + 0.25, z), EntitySpawnReason.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				{
					final Vec3 _center = new Vec3((x + 0.5), (y + 0.25), (z + 0.5));
					for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(0.35 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
						if (entityiterator instanceof SlugEntity) {
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 0);
							if (entityiterator instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_terrarium, 1);
							if (entityiterator instanceof LivingEntity _livingEntity40 && _livingEntity40.getAttributes().hasAttribute(Attributes.SCALE))
								_livingEntity40.getAttribute(Attributes.SCALE).setBaseValue(0.5);
							if (entityiterator instanceof LivingEntity _livingEntity41 && _livingEntity41.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
								_livingEntity41.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.005);
							if (entityiterator instanceof LivingEntity _livingEntity42 && _livingEntity42.getAttributes().hasAttribute(Attributes.JUMP_STRENGTH))
								_livingEntity42.getAttribute(Attributes.JUMP_STRENGTH).setBaseValue(0);
							{
								Entity _ent = entityiterator;
								_ent.teleportTo((x + 0.5), (y + 0.25), (z + 0.5));
								if (_ent instanceof ServerPlayer _serverPlayer)
									_serverPlayer.connection.teleport((x + 0.5), (y + 0.25), (z + 0.5), _ent.getYRot(), _ent.getXRot());
							}
						}
					}
				}
			}
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}