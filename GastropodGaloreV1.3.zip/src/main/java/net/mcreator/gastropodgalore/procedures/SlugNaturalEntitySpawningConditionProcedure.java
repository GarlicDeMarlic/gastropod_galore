package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.TagKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.init.GastropodGaloreModEntities;

public class SlugNaturalEntitySpawningConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if (world.getBiome(BlockPos.containing(x, y, z)).is(TagKey.create(Registries.BIOME, ResourceLocation.parse("gastropod_galore:snail_spawns")))) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = GastropodGaloreModEntities.SLUG.get().spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			return true;
		} else if ((world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("meadow")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("plains"))
				|| world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("sparse_jungle")) || world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("windswept_forest"))) && world.getLevelData().isRaining()) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = GastropodGaloreModEntities.SLUG.get().spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			return true;
		}
		return false;
	}
}