package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.Difficulty;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.mcreator.gastropodgalore.entity.VolcanicSnailEntity;
import net.mcreator.gastropodgalore.entity.MagmaSnailEntity;

import javax.annotation.Nullable;

import java.util.Comparator;

@EventBusSubscriber
public class VolcanicSnailSteamDamageProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double fromZ = 0;
		double fromX = 0;
		double fromY = 0;
		if (entity instanceof VolcanicSnailEntity) {
			if (entity.getPersistentData().getDoubleOr("steam", 0) >= 40) {
				for (int index0 = 0; index0 < (int) Mth.nextDouble(RandomSource.create(), 1, 3); index0++) {
					world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, (entity.getX() + Mth.nextDouble(RandomSource.create(), -6, 6)), (entity.getY()), (entity.getZ() + Mth.nextDouble(RandomSource.create(), -6, 6)),
							(Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
				}
				entity.getPersistentData().putDouble("steam", 0);
			} else {
				entity.getPersistentData().putDouble("steam", (entity.getPersistentData().getDoubleOr("steam", 0) + 1));
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(10 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entity.getPersistentData().getDoubleOr("cooldown", 0) >= 20) {
						if (!(entityiterator instanceof Player _plr ? _plr.getAbilities().instabuild : false)) {
							entityiterator.igniteForSeconds(10);
							entityiterator.hurt(new DamageSource(world.holderOrThrow(DamageTypes.ON_FIRE), entity), 6);
							for (int index1 = 0; index1 < (int) Mth.nextDouble(RandomSource.create(), 1, 3); index1++) {
								world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03,
										(Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
							}
							entity.getPersistentData().putDouble("cooldown", 0);
						}
					} else {
						entity.getPersistentData().putDouble("cooldown", (entity.getPersistentData().getDoubleOr("cooldown", 0) + 1));
					}
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(64 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (!(world.getDifficulty() == Difficulty.PEACEFUL)) {
						if (entityiterator == (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null)) {
							if (entity.getPersistentData().getDoubleOr("fireball", 0) >= 40) {
								entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ())));
								{
									Entity _shootFrom = entity;
									Level projectileLevel = _shootFrom.level();
									if (!projectileLevel.isClientSide()) {
										Projectile _entityToSpawn = initProjectileProperties(new LargeFireball(EntityType.FIREBALL, projectileLevel), entity, new Vec3(0, 0, 0));
										_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
										_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 1, 5);
										projectileLevel.addFreshEntity(_entityToSpawn);
									}
								}
								entity.getPersistentData().putDouble("fireball", 0);
							} else {
								entity.getPersistentData().putDouble("fireball", (entity.getPersistentData().getDoubleOr("fireball", 0) + 1));
							}
						}
					}
				}
			}
		} else if (entity instanceof MagmaSnailEntity) {
			if (entity instanceof Mob _mobEnt45 && _mobEnt45.isAggressive()) {
				if (entity.getPersistentData().getDoubleOr("steam", 0) >= 40) {
					for (int index2 = 0; index2 < (int) Mth.nextDouble(RandomSource.create(), 1, 3); index2++) {
						world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, (entity.getX() + Mth.nextDouble(RandomSource.create(), -4, 4)), (entity.getY()), (entity.getZ() + Mth.nextDouble(RandomSource.create(), -4, 4)),
								(Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
					}
					entity.getPersistentData().putDouble("steam", 0);
				} else {
					entity.getPersistentData().putDouble("steam", (entity.getPersistentData().getDoubleOr("steam", 0) + 1));
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(8 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entity instanceof Mob _mobEnt59 && _mobEnt59.isAggressive()) {
						if (entity.getPersistentData().getDoubleOr("cooldown", 0) >= 20) {
							if (!(entityiterator instanceof Player _plr ? _plr.getAbilities().instabuild : false)) {
								entityiterator.igniteForSeconds(10);
								entityiterator.hurt(new DamageSource(world.holderOrThrow(DamageTypes.ON_FIRE), entity), 3);
								for (int index3 = 0; index3 < (int) Mth.nextDouble(RandomSource.create(), 1, 3); index3++) {
									world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03,
											(Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
								}
								entity.getPersistentData().putDouble("cooldown", 0);
							}
						} else {
							entity.getPersistentData().putDouble("cooldown", (entity.getPersistentData().getDoubleOr("cooldown", 0) + 1));
						}
					}
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(64 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (!(world.getDifficulty() == Difficulty.PEACEFUL)) {
						if (entityiterator == (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null)) {
							if (entity.getPersistentData().getDoubleOr("fireball", 0) >= 60) {
								entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ())));
								{
									Entity _shootFrom = entity;
									Level projectileLevel = _shootFrom.level();
									if (!projectileLevel.isClientSide()) {
										Projectile _entityToSpawn = initProjectileProperties(new LargeFireball(EntityType.FIREBALL, projectileLevel), entity, new Vec3(0, 0, 0));
										_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
										_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 1, 5);
										projectileLevel.addFreshEntity(_entityToSpawn);
									}
								}
								entity.getPersistentData().putDouble("fireball", 0);
							} else {
								entity.getPersistentData().putDouble("fireball", (entity.getPersistentData().getDoubleOr("fireball", 0) + 1));
							}
						}
					}
				}
			}
		}
	}

	private static Projectile initProjectileProperties(Projectile entityToSpawn, Entity shooter, Vec3 acceleration) {
		entityToSpawn.setOwner(shooter);
		if (!Vec3.ZERO.equals(acceleration)) {
			entityToSpawn.setDeltaMovement(acceleration);
			entityToSpawn.hasImpulse = true;
		}
		return entityToSpawn;
	}
}