package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.ImmortalSnailEntity;

public class ImmortalSnailDisplayCondition1Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof ImmortalSnailEntity _datEntI ? _datEntI.getEntityData().get(ImmortalSnailEntity.DATA_variant) : 0) == 1;
	}
}