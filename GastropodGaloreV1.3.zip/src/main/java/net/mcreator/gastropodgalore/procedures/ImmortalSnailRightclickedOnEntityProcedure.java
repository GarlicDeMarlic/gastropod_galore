package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.entity.ImmortalSnailEntity;

public class ImmortalSnailRightclickedOnEntityProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (itemstack.getItem() == Items.ENCHANTED_GOLDEN_APPLE) {
			itemstack.setCount(itemstack.getCount() - 1);
			for (int index0 = 0; index0 < (int) Mth.nextDouble(RandomSource.create(), 3, 5); index0++) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
					entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			if (entity instanceof ImmortalSnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(ImmortalSnailEntity.DATA_immortality, (int) ((entity instanceof ImmortalSnailEntity _datEntI ? _datEntI.getEntityData().get(ImmortalSnailEntity.DATA_immortality) : 0) + 1200));
		}
	}
}