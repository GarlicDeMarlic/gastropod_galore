package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

public class VolcanicSnailOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double posX = 0;
		double posY = 0;
		double posZ = 0;
		Entity player = null;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < 6; index0++) {
			sy = -3;
			for (int index1 = 0; index1 < 6; index1++) {
				sz = -3;
				for (int index2 = 0; index2 < 6; index2++) {
					if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.ICE || (world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.PACKED_ICE
							|| (world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.BLUE_ICE) {
						world.setBlock(BlockPos.containing(x + sx, y + sy, z + sz), Blocks.AIR.defaultBlockState(), 3);
						world.setBlock(BlockPos.containing(x + sx, y + sy, z + sz), Blocks.WATER.defaultBlockState(), 3);
						world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, (x + sx), (y + sy), (z + sz), (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if ((entity.getPersistentData().getDoubleOr("smoke", 0) == 40 || entity.getPersistentData().getDoubleOr("smoke", 0) > 40) && !(entity instanceof Mob _mobEnt13 && _mobEnt13.isAggressive())) {
			for (int index3 = 0; index3 < (int) Mth.nextDouble(RandomSource.create(), 2, 3); index3++) {
				world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			}
			for (int index4 = 0; index4 < (int) Mth.nextDouble(RandomSource.create(), 1, 2); index4++) {
				world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.7, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			}
			entity.getPersistentData().putDouble("smoke", 0);
		} else if ((entity.getPersistentData().getDoubleOr("smoke", 0) == 30 || entity.getPersistentData().getDoubleOr("smoke", 0) > 30) && entity instanceof Mob _mobEnt25 && _mobEnt25.isAggressive()) {
			for (int index5 = 0; index5 < (int) Mth.nextDouble(RandomSource.create(), 2, 4); index5++) {
				world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			}
			for (int index6 = 0; index6 < (int) Mth.nextDouble(RandomSource.create(), 1, 3); index6++) {
				world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)), 0.8, (Mth.nextDouble(RandomSource.create(), -0.1, 0.1)));
			}
			for (int index7 = 0; index7 < (int) Mth.nextDouble(RandomSource.create(), 1, 2); index7++) {
				world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			}
			entity.getPersistentData().putDouble("smoke", 0);
		} else {
			entity.getPersistentData().putDouble("smoke", (entity.getPersistentData().getDoubleOr("smoke", 0) + 1));
		}
	}
}