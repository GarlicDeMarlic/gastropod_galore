package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.AppleSnailEntity;

public class HidingAppleSnailPlaybackConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_hide) : 0) == 2;
	}
}