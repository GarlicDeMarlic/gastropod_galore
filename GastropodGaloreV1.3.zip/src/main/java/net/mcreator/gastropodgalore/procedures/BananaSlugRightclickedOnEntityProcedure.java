package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.items.ItemHandlerHelper;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.ItemTags;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.gastropodgalore.init.GastropodGaloreModBlocks;
import net.mcreator.gastropodgalore.entity.BananaSlugEntity;

public class BananaSlugRightclickedOnEntityProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, ItemStack itemstack) {
		if (entity == null || sourceentity == null)
			return;
		ItemStack terrarium = ItemStack.EMPTY;
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food"))) && (entity instanceof BananaSlugEntity _datEntI ? _datEntI.getEntityData().get(BananaSlugEntity.DATA_breed_cooldown) : 0) == 0
				&& !(entity instanceof LivingEntity _livEnt3 && _livEnt3.isBaby())) {
			if (!(sourceentity instanceof Player _plr ? _plr.getAbilities().instabuild : false)) {
				itemstack.setCount(itemstack.getCount() - 1);
			}
			if (itemstack.getItem() == (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
				if (entity instanceof LivingEntity _entity)
					_entity.swing(InteractionHand.MAIN_HAND, true);
			} else {
				if (entity instanceof LivingEntity _entity)
					_entity.swing(InteractionHand.OFF_HAND, true);
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.HEART, x, (y + 0.5), z, 5, 0.3, 0.3, 0.3, 1);
			if (entity instanceof BananaSlugEntity _datEntSetI)
				_datEntSetI.getEntityData().set(BananaSlugEntity.DATA_breed_cooldown, 1200);
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "data merge entity @s {InLove:600}");
				}
			}
		}
		if (itemstack.getItem() == GastropodGaloreModBlocks.TERRARIUM.get().asItem() && !(entity instanceof LivingEntity _livEnt19 && _livEnt19.isBaby())) {
			if (itemstack.getItem() == (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
				terrarium = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).copy();
			} else {
				terrarium = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).copy();
			}
			if (!(sourceentity instanceof Player _plr ? _plr.getAbilities().instabuild : false)) {
				itemstack.setCount(itemstack.getCount() - 1);
			}
			if (sourceentity instanceof Player _player) {
				ItemStack _setstack = new ItemStack(GastropodGaloreModBlocks.BANANA_SLUG_TERRARIUM.get()).copy();
				_setstack.setCount(1);
				ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
			}
			if (itemstack.getItem() == (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
				if (sourceentity instanceof LivingEntity _entity)
					_entity.swing(InteractionHand.MAIN_HAND, true);
			} else {
				if (sourceentity instanceof LivingEntity _entity)
					_entity.swing(InteractionHand.OFF_HAND, true);
			}
			if (!entity.level().isClientSide())
				entity.discard();
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.bottle.fill")), SoundSource.PLAYERS, (float) 0.9, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.bottle.fill")), SoundSource.PLAYERS, (float) 0.9, 1, false);
				}
			}
		}
	}
}