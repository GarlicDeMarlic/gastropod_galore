package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.gastropodgalore.entity.PaintedSnailEntity;

import java.util.Comparator;

public class PaintedSnailOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof LivingEntity _livEnt0 && _livEnt0.isBaby())) {
			if (Mth.nextInt(RandomSource.create(), 0, 7) == 0) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 0);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 1) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 1);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 2) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 2);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 3) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 3);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 4) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 4);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 5) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 5);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 6) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 6);
			} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 7) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 7);
			}
		} else {
			{
				final Vec3 _center = new Vec3((entity.getX()), (entity.getY()), (entity.getZ()));
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof PaintedSnailEntity && entity instanceof LivingEntity _livEnt21 && _livEnt21.isBaby()) {
						if (entity instanceof PaintedSnailEntity _datEntSetI)
							_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, (int) (entityiterator instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_variant) : 0));
					} else if (!(entityiterator instanceof PaintedSnailEntity) && entity instanceof LivingEntity _livEnt25 && _livEnt25.isBaby()) {
						if (Mth.nextInt(RandomSource.create(), 0, 7) == 0) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 0);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 1) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 1);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 2) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 2);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 3) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 3);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 4) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 4);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 5) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 5);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 6) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 6);
						} else if (Mth.nextInt(RandomSource.create(), 0, 7) == 7) {
							if (entity instanceof PaintedSnailEntity _datEntSetI)
								_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_variant, 7);
						}
					}
				}
			}
		}
	}
}