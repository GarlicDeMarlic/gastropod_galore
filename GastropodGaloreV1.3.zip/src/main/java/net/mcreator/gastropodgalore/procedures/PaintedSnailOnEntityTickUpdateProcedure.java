package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.gastropodgalore.entity.PaintedSnailEntity;

public class PaintedSnailOnEntityTickUpdateProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_breed_cooldown) : 0) > 0) {
			if (entity instanceof PaintedSnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_breed_cooldown, (int) ((entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_breed_cooldown) : 0) - 1));
		}
		if (entity instanceof PaintedSnailEntity) {
			if ((entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_hide_timer) : 0) > 0) {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_hide_timer, (int) ((entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_hide_timer) : 0) - 1));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 1, 255, false, false));
				if ((entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_hide_timer) : 0) > 20) {
					if (entity instanceof PaintedSnailEntity _datEntSetI)
						_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_hide, 2);
				} else if ((entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_hide_timer) : 0) <= 20) {
					if (entity instanceof PaintedSnailEntity _datEntSetI)
						_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_hide, 1);
				}
			} else {
				if (entity instanceof PaintedSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(PaintedSnailEntity.DATA_hide, 0);
			}
		}
	}
}