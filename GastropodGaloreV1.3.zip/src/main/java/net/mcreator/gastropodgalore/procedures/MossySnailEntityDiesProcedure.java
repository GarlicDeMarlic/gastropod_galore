package net.mcreator.gastropodgalore.procedures;

public class MossySnailEntityDiesProcedure {
	public static void execute() {
	}
}