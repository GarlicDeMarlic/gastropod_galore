package net.mcreator.gastropodgalore.procedures;

public class SlugEntityDiesProcedure {
	public static void execute() {
	}
}