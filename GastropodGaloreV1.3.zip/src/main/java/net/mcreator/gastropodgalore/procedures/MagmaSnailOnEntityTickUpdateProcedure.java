package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.entity.MagmaSnailEntity;

public class MagmaSnailOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		boolean found = false;
		sx = -3;
		found = false;
		for (int index0 = 0; index0 < 6; index0++) {
			sy = -3;
			for (int index1 = 0; index1 < 6; index1++) {
				sz = -3;
				for (int index2 = 0; index2 < 6; index2++) {
					if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == Blocks.ICE) {
						world.setBlock(BlockPos.containing(x + sx, y + sy, z + sz), Blocks.AIR.defaultBlockState(), 3);
						world.setBlock(BlockPos.containing(x + sx, y + sy, z + sz), Blocks.WATER.defaultBlockState(), 3);
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if ((entity.getPersistentData().getDoubleOr("smoke", 0) == 60 || entity.getPersistentData().getDoubleOr("smoke", 0) > 60) && !(entity instanceof Mob _mobEnt6 && _mobEnt6.isAggressive())) {
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			entity.getPersistentData().putDouble("smoke", 0);
		} else if (entity.getPersistentData().getDoubleOr("smoke", 0) >= 30 && entity instanceof Mob _mobEnt12 && _mobEnt12.isAggressive()) {
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			entity.getPersistentData().putDouble("smoke", 0);
		} else {
			entity.getPersistentData().putDouble("smoke", (entity.getPersistentData().getDoubleOr("smoke", 0) + 1));
		}
		if (entity.getPersistentData().getDoubleOr("fuel_cooldown", 0) > 0) {
			entity.getPersistentData().putDouble("fuel_cooldown", (entity.getPersistentData().getDoubleOr("fuel_cooldown", 0) - 1));
		}
		if ((entity instanceof MagmaSnailEntity _datEntI ? _datEntI.getEntityData().get(MagmaSnailEntity.DATA_cooking_cooldown) : 0) > 0) {
			if (entity instanceof MagmaSnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MagmaSnailEntity.DATA_cooking_cooldown, (int) ((entity instanceof MagmaSnailEntity _datEntI ? _datEntI.getEntityData().get(MagmaSnailEntity.DATA_cooking_cooldown) : 0) - 1));
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:hot")))
				|| (world.getBlockState(BlockPos.containing(x, y - 1, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:hot")))) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.WATER || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.BUBBLE_COLUMN) {
				if (entity instanceof LivingEntity _livingEntity39 && _livingEntity39.getAttributes().hasAttribute(NeoForgeMod.SWIM_SPEED))
					_livingEntity39.getAttribute(NeoForgeMod.SWIM_SPEED).setBaseValue(4);
			} else {
				if (entity instanceof LivingEntity _livingEntity40 && _livingEntity40.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
					_livingEntity40.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.3);
			}
		} else {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.WATER || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.BUBBLE_COLUMN) {
				if (entity instanceof LivingEntity _livingEntity45 && _livingEntity45.getAttributes().hasAttribute(NeoForgeMod.SWIM_SPEED))
					_livingEntity45.getAttribute(NeoForgeMod.SWIM_SPEED).setBaseValue(1);
			} else {
				if (entity instanceof LivingEntity _livingEntity46 && _livingEntity46.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
					_livingEntity46.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.1);
			}
		}
	}
}