package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.init.GastropodGaloreModItems;
import net.mcreator.gastropodgalore.entity.MagmaSnailEntity;

public class MagmaSnailRightclickedOnEntityProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		ItemStack raw = ItemStack.EMPTY;
		ItemStack cooked = ItemStack.EMPTY;
		boolean found = false;
		double itemstack = 0;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:ms_cookable"))) && entity.getPersistentData().getDoubleOr("fuel_cooldown", 0) == 0
				&& (entity instanceof MagmaSnailEntity _datEntI ? _datEntI.getEntityData().get(MagmaSnailEntity.DATA_cooking_cooldown) : 0) == 0) {
			if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.PORKCHOP) {
				cooked = new ItemStack(Items.COOKED_PORKCHOP).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BEEF) {
				cooked = new ItemStack(Items.COOKED_BEEF).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.MUTTON) {
				cooked = new ItemStack(Items.COOKED_MUTTON).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CHICKEN) {
				cooked = new ItemStack(Items.COOKED_CHICKEN).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RABBIT) {
				cooked = new ItemStack(Items.COOKED_RABBIT).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.COD) {
				cooked = new ItemStack(Items.COOKED_COD).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.SALMON) {
				cooked = new ItemStack(Items.COOKED_SALMON).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RAW_IRON) {
				cooked = new ItemStack(Items.IRON_INGOT).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.RAW_IRON_BLOCK.asItem()) {
				cooked = new ItemStack(Blocks.IRON_BLOCK).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RAW_GOLD
					|| (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.NETHER_GOLD_ORE.asItem()) {
				cooked = new ItemStack(Items.GOLD_INGOT).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.RAW_GOLD_BLOCK.asItem()) {
				cooked = new ItemStack(Blocks.GOLD_BLOCK).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.RAW_COPPER_BLOCK.asItem()) {
				cooked = new ItemStack(Blocks.COPPER_BLOCK).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.RAW_COPPER) {
				cooked = new ItemStack(Items.COPPER_INGOT).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.CLAY.asItem()) {
				cooked = new ItemStack(Blocks.BRICKS).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CLAY_BALL) {
				cooked = new ItemStack(Items.BRICK).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.CLAY.asItem()) {
				cooked = new ItemStack(Blocks.BRICKS).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.POTATO) {
				cooked = new ItemStack(Items.BAKED_POTATO).copy();
			} else if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.CARROT) {
				cooked = new ItemStack(GastropodGaloreModItems.ROASTED_CARROT.get()).copy();
			}
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.02, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.02, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.02, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.02, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.02, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.07, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.07, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.LAVA, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)), 0.07, (Mth.nextDouble(RandomSource.create(), -0.01, 0.01)));
			world.addParticle(ParticleTypes.FLAME, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)));
			world.addParticle(ParticleTypes.FLAME, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)));
			world.addParticle(ParticleTypes.FLAME, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)));
			world.addParticle(ParticleTypes.FLAME, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)));
			world.addParticle(ParticleTypes.FLAME, x, y, z, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)), 0.03, (Mth.nextDouble(RandomSource.create(), -0.05, 0.05)));
			itemstack = (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount();
			if (sourceentity instanceof LivingEntity _entity) {
				ItemStack _setstack83 = cooked.copy();
				_setstack83.setCount((int) itemstack);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack83);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.firecharge.use")), SoundSource.NEUTRAL, (float) 0.7,
							(float) Mth.nextDouble(RandomSource.create(), 0.9, 1.1));
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.firecharge.use")), SoundSource.NEUTRAL, (float) 0.7, (float) Mth.nextDouble(RandomSource.create(), 0.9, 1.1), false);
				}
			}
			if (world.getBiome(BlockPos.containing(x, y, z)).is(TagKey.create(Registries.BIOME, ResourceLocation.parse("minecraft:is_nether")))
					|| (world.getBlockState(BlockPos.containing(x, y - 1, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:hot")))
					|| (world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:hot")))) {
				entity.getPersistentData().putDouble("fuel_cooldown", (itemstack * 50));
				if (entity instanceof MagmaSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MagmaSnailEntity.DATA_cooking_cooldown, (int) (itemstack * 50));
			} else {
				entity.getPersistentData().putDouble("fuel_cooldown", (itemstack * 100));
				if (entity instanceof MagmaSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MagmaSnailEntity.DATA_cooking_cooldown, (int) (itemstack * 100));
			}
		}
	}
}