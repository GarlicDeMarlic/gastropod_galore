package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.gastropodgalore.entity.AppleSnailEntity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class AppleSnailSuffacateProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof AppleSnailEntity) {
			if (!isInWaterRainOrBubble(entity)) {
				if (entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
					_livingEntity2.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.075);
				if (entity.getPersistentData().getDoubleOr("drown_timer", 0) >= 600) {
					entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 1);
					if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) == 10) {
						entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 1);
					} else {
						entity.getPersistentData().putDouble("additionaldrown_timer", (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) + 1));
					}
					if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) > 10) {
						if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) == 20) {
							entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 1);
						} else {
							entity.getPersistentData().putDouble("additionaldrown_timer", (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) + 1));
						}
					}
					if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) > 20) {
						if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) == 30) {
							entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 10);
						} else {
							entity.getPersistentData().putDouble("additionaldrown_timer", (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) + 1));
						}
					}
				} else {
					entity.getPersistentData().putDouble("drown_timer", (entity.getPersistentData().getDoubleOr("drown_timer", 0) + 1));
				}
			} else {
				if (entity instanceof LivingEntity _livingEntity25 && _livingEntity25.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
					_livingEntity25.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.1);
				entity.getPersistentData().putDouble("drown_timer", 0);
				entity.getPersistentData().putDouble("additionaldrown_timer", 0);
			}
		}
	}

	private static boolean isInWaterRainOrBubble(Entity entity) {
		return entity.isInWaterOrRain() || entity.getInBlockState().is(Blocks.BUBBLE_COLUMN);
	}
}