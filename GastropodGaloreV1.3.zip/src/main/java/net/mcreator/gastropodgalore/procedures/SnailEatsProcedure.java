package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.gastropodgalore.entity.SnailEntity;

import java.util.Comparator;

public class SnailEatsProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SnailEntity) {
			if ((world.getBlockState(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:crop")))) {
				world.destroyBlock(BlockPos.containing(x, y, z), false);
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 5, false, false));
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.5, 0.5, 0.5, 1);
				if (Math.random() < 0.7) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Items.SLIME_BALL));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				}
				if (!(entity instanceof LivingEntity _livEnt13 && _livEnt13.isBaby())) {
					if (Math.random() < 0.7) {
						if (world instanceof ServerLevel _level)
							_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
									"summon gastropod_galore:snail ~ ~ ~ {Age:-25000}");
						{
							final Vec3 _center = new Vec3(x, y, z);
							for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
								if (entityiterator instanceof SnailEntity && entityiterator instanceof LivingEntity _livEnt16 && _livEnt16.isBaby()) {
									if (Mth.nextInt(RandomSource.create(), 1, 100) < 50) {
										if (entityiterator instanceof SnailEntity _datEntSetI)
											_datEntSetI.getEntityData().set(SnailEntity.DATA_variant, 0);
									} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 70) {
										if (entityiterator instanceof SnailEntity _datEntSetI)
											_datEntSetI.getEntityData().set(SnailEntity.DATA_variant, 1);
									} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 90) {
										if (entityiterator instanceof SnailEntity _datEntSetI)
											_datEntSetI.getEntityData().set(SnailEntity.DATA_variant, 2);
									} else {
										if (entityiterator instanceof SnailEntity _datEntSetI)
											_datEntSetI.getEntityData().set(SnailEntity.DATA_variant, 3);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}