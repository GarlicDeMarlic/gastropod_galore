package net.mcreator.gastropodgalore.client.model;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.0.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modellarge_snail extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "modellarge_snail"), "main");
	public final ModelPart snail;
	public final ModelPart body;
	public final ModelPart eyes;
	public final ModelPart eye1;
	public final ModelPart eye2;
	public final ModelPart shell;

	public Modellarge_snail(ModelPart root) {
		super(root);
		this.snail = root.getChild("snail");
		this.body = this.snail.getChild("body");
		this.eyes = this.body.getChild("eyes");
		this.eye1 = this.eyes.getChild("eye1");
		this.eye2 = this.eyes.getChild("eye2");
		this.shell = this.snail.getChild("shell");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition snail = partdefinition.addOrReplaceChild("snail", CubeListBuilder.create(), PartPose.offset(0.0F, 23.0F, 0.0F));
		PartDefinition body = snail.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 0).addBox(-2.12F, -2.0F, -4.3F, 4.0F, 2.0F, 10.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-2.12F, -2.0F, -4.3F, 4.0F, 2.0F, 10.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 1.0F, 0.0F));
		PartDefinition cube_r1 = body.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(8, 7).mirror().addBox(0.05F, -0.5F, -0.5F, 0.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(1.7F, -0.6F, -4.5F, 0.0F, -0.3054F, 0.0F));
		PartDefinition cube_r2 = body.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(8, 7).addBox(0.0F, -0.5F, -0.5F, 0.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0F, -0.6F, -4.5F, 0.0F, 0.3054F, 0.0F));
		PartDefinition eyes = body.addOrReplaceChild("eyes", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.11F, -1.8135F, -4.0688F, 0.2182F, 0.0F, 0.0F));
		PartDefinition eye1 = eyes.addOrReplaceChild("eye1", CubeListBuilder.create().texOffs(24, 12).addBox(-0.5F, -2.9F, 0.0F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(1.49F, -0.2666F, -0.1992F));
		PartDefinition eye2 = eyes.addOrReplaceChild("eye2", CubeListBuilder.create().texOffs(24, 15).addBox(-0.52F, -3.0F, -0.06F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(-1.47F, -0.1665F, -0.1392F));
		PartDefinition shell = snail.addOrReplaceChild("shell", CubeListBuilder.create().texOffs(0, 12).addBox(-3.0F, -4.5F, -4.5F, 6.0F, 9.0F, 9.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.1F, -4.6387F, 1.3644F, 0.2182F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 32, 32);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}

}