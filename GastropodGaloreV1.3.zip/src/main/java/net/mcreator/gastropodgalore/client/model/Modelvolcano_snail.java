package net.mcreator.gastropodgalore.client.model;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.0.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelvolcano_snail extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("gastropod_galore", "modelvolcano_snail"), "main");
	public final ModelPart body;
	public final ModelPart mainbody;
	public final ModelPart eyes;
	public final ModelPart eye_1;
	public final ModelPart eye_2;
	public final ModelPart foot;
	public final ModelPart shell;

	public Modelvolcano_snail(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.mainbody = this.body.getChild("mainbody");
		this.eyes = this.mainbody.getChild("eyes");
		this.eye_1 = this.eyes.getChild("eye_1");
		this.eye_2 = this.eyes.getChild("eye_2");
		this.foot = this.mainbody.getChild("foot");
		this.shell = this.body.getChild("shell");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition body = partdefinition.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));
		PartDefinition mainbody = body.addOrReplaceChild("mainbody",
				CubeListBuilder.create().texOffs(41, 53).addBox(-3.0F, -4.0F, -7.0F, 0.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(41, 53).addBox(3.0F, -4.0F, -7.0F, 0.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition eyes = mainbody.addOrReplaceChild("eyes", CubeListBuilder.create(), PartPose.offset(0.0F, -4.9131F, -5.19F));
		PartDefinition eye_1 = eyes.addOrReplaceChild("eye_1", CubeListBuilder.create(), PartPose.offset(-2.0F, 0.0F, 0.0F));
		PartDefinition cube_r1 = eye_1.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(40, 42).addBox(-1.0F, 0.0F, -5.0F, 2.0F, 0.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.0869F, -0.81F, -0.6545F, 0.0F, 0.0F));
		PartDefinition eye_2 = eyes.addOrReplaceChild("eye_2", CubeListBuilder.create(), PartPose.offset(2.0F, 0.0F, 0.0F));
		PartDefinition cube_r2 = eye_2.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(44, 42).addBox(-1.0F, 0.0F, -5.0F, 2.0F, 0.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.0869F, -0.81F, -0.6545F, 0.0F, 0.0F));
		PartDefinition foot = mainbody.addOrReplaceChild("foot",
				CubeListBuilder.create().texOffs(0, 24).addBox(-4.0F, -2.0F, -7.0F, 8.0F, 2.0F, 16.0F, new CubeDeformation(0.0F)).texOffs(0, 42).addBox(-3.5F, -5.0F, -5.9F, 7.0F, 3.0F, 13.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition shell = body.addOrReplaceChild("shell", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -8.5F, 2.0F, 0.2182F, 0.0F, 0.0F));
		PartDefinition cube_r3 = shell.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.0873F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}

}