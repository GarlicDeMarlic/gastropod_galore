// Made with Blockbench 5.0.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelpainted_snail<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "painted_snail"), "main");
	private final ModelPart snail;
	private final ModelPart body;
	private final ModelPart eyes;
	private final ModelPart eye1;
	private final ModelPart eye2;
	private final ModelPart shell;

	public Modelpainted_snail(ModelPart root) {
		this.snail = root.getChild("snail");
		this.body = this.snail.getChild("body");
		this.eyes = this.body.getChild("eyes");
		this.eye1 = this.eyes.getChild("eye1");
		this.eye2 = this.eyes.getChild("eye2");
		this.shell = this.snail.getChild("shell");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition snail = partdefinition.addOrReplaceChild("snail", CubeListBuilder.create(),
				PartPose.offset(-0.25F, 22.1134F, 0.4583F));

		PartDefinition body = snail.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 12).addBox(-1.5F,
				-1.0135F, -4.0148F, 3.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-0.25F, 0.9001F, 0.2565F));

		PartDefinition cube_r1 = body.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(22, 0).addBox(0.0F, -0.5F, -1.0F, 0.0F, 1.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.1F, 0.4865F, -4.0148F, 0.0F, -0.2182F, 0.0F));

		PartDefinition cube_r2 = body.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(0, 22).addBox(0.0F, -0.5F, -1.0F, 0.0F, 1.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.1F, 0.4865F, -4.0148F, 0.0F, 0.2182F, 0.0F));

		PartDefinition eyes = body.addOrReplaceChild("eyes", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.0F, -0.9594F, -3.9556F, 0.5672F, 0.0F, 0.0F));

		PartDefinition eye1 = eyes.addOrReplaceChild("eye1", CubeListBuilder.create().texOffs(22, 3).addBox(-0.54F,
				-3.0F, -0.06F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(1.02F, 0.0F, 0.0F));

		PartDefinition eye2 = eyes.addOrReplaceChild("eye2", CubeListBuilder.create().texOffs(4, 22).addBox(-0.52F,
				-3.0F, -0.06F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(-0.98F, 0.0F, 0.0F));

		PartDefinition shell = snail.addOrReplaceChild("shell",
				CubeListBuilder.create().texOffs(0, 0).addBox(-2.5F, -3.0F, -3.0F, 5.0F, 6.0F, 6.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.25F, -1.8865F, 0.4583F, 0.2182F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 32, 32);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		snail.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}