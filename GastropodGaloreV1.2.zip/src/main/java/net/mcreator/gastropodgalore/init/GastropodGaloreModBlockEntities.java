/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.gastropodgalore.block.entity.*;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

@EventBusSubscriber
public class GastropodGaloreModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, GastropodGaloreMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SnailShellBlockEntity>> SNAIL_SHELL = register("snail_shell", GastropodGaloreModBlocks.SNAIL_SHELL, SnailShellBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AppleSnailShellBlockEntity>> APPLE_SNAIL_SHELL = register("apple_snail_shell", GastropodGaloreModBlocks.APPLE_SNAIL_SHELL, AppleSnailShellBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MossySnailShellBlockEntity>> MOSSY_SNAIL_SHELL_BROWN = register("mossy_snail_shell_brown", GastropodGaloreModBlocks.MOSSY_SNAIL_SHELL_BROWN, MossySnailShellBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MossySnailShell1BlockEntity>> MOSSY_SNAIL_SHELL_RED = register("mossy_snail_shell_red", GastropodGaloreModBlocks.MOSSY_SNAIL_SHELL_RED, MossySnailShell1BlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MossySnailShell2BlockEntity>> MOSSY_SNAIL_SHELL_GREEN = register("mossy_snail_shell_green", GastropodGaloreModBlocks.MOSSY_SNAIL_SHELL_GREEN,
			MossySnailShell2BlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MossySnailShell3BlockEntity>> MOSSY_SNAIL_SHELL_YELLOW = register("mossy_snail_shell_yellow", GastropodGaloreModBlocks.MOSSY_SNAIL_SHELL_YELLOW,
			MossySnailShell3BlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> new BlockEntityType(supplier, block.get()));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, SNAIL_SHELL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, APPLE_SNAIL_SHELL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MOSSY_SNAIL_SHELL_BROWN.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MOSSY_SNAIL_SHELL_RED.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MOSSY_SNAIL_SHELL_GREEN.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MOSSY_SNAIL_SHELL_YELLOW.get(), SidedInvWrapper::new);
	}
}