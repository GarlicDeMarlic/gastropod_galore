/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.gastropodgalore.item.RoastedCarrotItem;
import net.mcreator.gastropodgalore.GastropodGaloreMod;

import java.util.function.Function;

public class GastropodGaloreModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GastropodGaloreMod.MODID);
	public static final DeferredItem<Item> SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> BANANA_SLUG_SPAWN_EGG;
	public static final DeferredItem<Item> SLUG_SPAWN_EGG;
	public static final DeferredItem<Item> APPLE_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> VOLCANIC_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> MAGMA_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> SEA_BUNNY_SPAWN_EGG;
	public static final DeferredItem<Item> ROASTED_CARROT;
	public static final DeferredItem<Item> SNAIL_SHELL;
	public static final DeferredItem<Item> VOLCANIC_SNAIL_SHELL;
	public static final DeferredItem<Item> PAINTED_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> MOSSY_SNAIL_SPAWN_EGG;
	public static final DeferredItem<Item> TERRARIUM;
	public static final DeferredItem<Item> GARDEN_SNAIL_TERRARIUM;
	public static final DeferredItem<Item> GARDEN_SNAIL_TERRARIUM_1;
	public static final DeferredItem<Item> GARDEN_SNAIL_TERRARIUM_2;
	public static final DeferredItem<Item> GARDEN_SNAIL_TERRARIUM_3;
	public static final DeferredItem<Item> APPLE_SNAIL_SHELL;
	public static final DeferredItem<Item> MOSSY_SNAIL_SHELL_BROWN;
	public static final DeferredItem<Item> SLUG_TERRARIUM;
	public static final DeferredItem<Item> SLUG_TERRARIUM_1;
	public static final DeferredItem<Item> SLUG_TERRARIUM_2;
	public static final DeferredItem<Item> SLUG_TERRARIUM_3;
	static {
		SNAIL_SPAWN_EGG = register("snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.SNAIL.get(), properties));
		BANANA_SLUG_SPAWN_EGG = register("banana_slug_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.BANANA_SLUG.get(), properties));
		SLUG_SPAWN_EGG = register("slug_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.SLUG.get(), properties));
		APPLE_SNAIL_SPAWN_EGG = register("apple_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.APPLE_SNAIL.get(), properties));
		VOLCANIC_SNAIL_SPAWN_EGG = register("volcanic_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.VOLCANIC_SNAIL.get(), properties));
		MAGMA_SNAIL_SPAWN_EGG = register("magma_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.MAGMA_SNAIL.get(), properties));
		SEA_BUNNY_SPAWN_EGG = register("sea_bunny_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.SEA_BUNNY.get(), properties));
		ROASTED_CARROT = register("roasted_carrot", RoastedCarrotItem::new);
		SNAIL_SHELL = block(GastropodGaloreModBlocks.SNAIL_SHELL);
		VOLCANIC_SNAIL_SHELL = block(GastropodGaloreModBlocks.VOLCANIC_SNAIL_SHELL, new Item.Properties().rarity(Rarity.UNCOMMON));
		PAINTED_SNAIL_SPAWN_EGG = register("painted_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.PAINTED_SNAIL.get(), properties));
		MOSSY_SNAIL_SPAWN_EGG = register("mossy_snail_spawn_egg", properties -> new SpawnEggItem(GastropodGaloreModEntities.MOSSY_SNAIL.get(), properties));
		TERRARIUM = block(GastropodGaloreModBlocks.TERRARIUM, new Item.Properties().stacksTo(16));
		GARDEN_SNAIL_TERRARIUM = block(GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM, new Item.Properties().stacksTo(1));
		GARDEN_SNAIL_TERRARIUM_1 = block(GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM_1, new Item.Properties().stacksTo(1));
		GARDEN_SNAIL_TERRARIUM_2 = block(GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM_2, new Item.Properties().stacksTo(1));
		GARDEN_SNAIL_TERRARIUM_3 = block(GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM_3, new Item.Properties().stacksTo(1));
		APPLE_SNAIL_SHELL = block(GastropodGaloreModBlocks.APPLE_SNAIL_SHELL);
		MOSSY_SNAIL_SHELL_BROWN = block(GastropodGaloreModBlocks.MOSSY_SNAIL_SHELL_BROWN);
		SLUG_TERRARIUM = block(GastropodGaloreModBlocks.SLUG_TERRARIUM, new Item.Properties().stacksTo(1));
		SLUG_TERRARIUM_1 = block(GastropodGaloreModBlocks.SLUG_TERRARIUM_1, new Item.Properties().stacksTo(1));
		SLUG_TERRARIUM_2 = block(GastropodGaloreModBlocks.SLUG_TERRARIUM_2, new Item.Properties().stacksTo(1));
		SLUG_TERRARIUM_3 = block(GastropodGaloreModBlocks.SLUG_TERRARIUM_3, new Item.Properties().stacksTo(1));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}