/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gastropodgalore.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber
public class GastropodGaloreModGameRules {
	public static GameRules.Key<GameRules.BooleanValue> VOLCANIC_HAVOC;
	public static GameRules.Key<GameRules.BooleanValue> NO_SLIMES;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		VOLCANIC_HAVOC = GameRules.register("volcanicHavoc", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
		NO_SLIMES = GameRules.register("noSlimes", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
	}
}