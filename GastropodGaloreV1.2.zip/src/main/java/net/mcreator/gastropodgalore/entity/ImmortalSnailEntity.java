package net.mcreator.gastropodgalore.entity;

import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.gastropodgalore.procedures.*;

import javax.annotation.Nullable;

public class ImmortalSnailEntity extends PathfinderMob {

	public static final EntityDataAccessor<String> TEXTURE = SynchedEntityData.defineId(ImmortalSnailEntity.class, EntityDataSerializers.STRING);
	public static final EntityDataAccessor<Integer> DATA_variant = SynchedEntityData.defineId(ImmortalSnailEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_hide = SynchedEntityData.defineId(ImmortalSnailEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_tp = SynchedEntityData.defineId(ImmortalSnailEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_immortality = SynchedEntityData.defineId(ImmortalSnailEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_death = SynchedEntityData.defineId(ImmortalSnailEntity.class, EntityDataSerializers.INT);
	public final AnimationState animationState0 = new AnimationState();
	public final AnimationState animationState1 = new AnimationState();

	public ImmortalSnailEntity(EntityType<ImmortalSnailEntity> type, Level world) {
		super(type, world);
		xpReward = 1;
		setNoAi(false);
		setPersistenceRequired();
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(TEXTURE, "snail_texture");
		builder.define(DATA_variant, 0);
		builder.define(DATA_hide, 0);
		builder.define(DATA_tp, 0);
		builder.define(DATA_immortality, 0);
		builder.define(DATA_death, 1);
	}

	public void setTexture(String texture) {
		this.entityData.set(TEXTURE, texture);
	}

	public String getTexture() {
		return this.entityData.get(TEXTURE);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, false) {
			@Override
			protected boolean canPerformAttack(LivingEntity entity) {
				return this.isTimeToAttack() && this.mob.distanceToSqr(entity) < (this.mob.getBbWidth() * this.mob.getBbWidth() + entity.getBbWidth()) && this.mob.getSensing().hasLineOfSight(entity);
			}
		});
		this.goalSelector.addGoal(2, new RandomStrollGoal(this, 0.8));
		this.targetSelector.addGoal(3, new NearestAttackableTargetGoal(this, Player.class, false, true));
		this.targetSelector.addGoal(4, new NearestAttackableTargetGoal(this, ServerPlayer.class, false, true));
		this.targetSelector.addGoal(5, new NearestAttackableTargetGoal(this, Player.class, true, false));
		this.targetSelector.addGoal(6, new NearestAttackableTargetGoal(this, ServerPlayer.class, true, false));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.goalSelector.addGoal(8, new FloatGoal(this));
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("gastropod_galore:snail_hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("gastropod_galore:snail_dies"));
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource damagesource, float amount) {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		Entity sourceentity = damagesource.getEntity();
		Entity immediatesourceentity = damagesource.getDirectEntity();

		ImmortalSnailEntityIsHurtProcedure.execute(x, y, z, damagesource, entity);
		if (damagesource.is(DamageTypes.IN_FIRE))
			return false;
		if (damagesource.getDirectEntity() instanceof AbstractArrow)
			return false;
		if (damagesource.is(DamageTypes.TRIDENT))
			return false;
		return super.hurtServer(level, damagesource, amount);
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		ImmortalSnailEntityDiesProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), source.getEntity());
	}

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficulty, EntitySpawnReason reason, @Nullable SpawnGroupData livingdata) {
		SpawnGroupData retval = super.finalizeSpawn(world, difficulty, reason, livingdata);
		ImmortalSnailOnInitialEntitySpawnProcedure.execute(world, this.getX(), this.getY(), this.getZ(), this);
		return retval;
	}

	@Override
	public void addAdditionalSaveData(ValueOutput valueOutput) {
		super.addAdditionalSaveData(valueOutput);
		valueOutput.putString("Texture", this.getTexture());
		valueOutput.putInt("Datavariant", this.entityData.get(DATA_variant));
		valueOutput.putInt("Datahide", this.entityData.get(DATA_hide));
		valueOutput.putInt("Datatp", this.entityData.get(DATA_tp));
		valueOutput.putInt("Dataimmortality", this.entityData.get(DATA_immortality));
		valueOutput.putInt("Datadeath", this.entityData.get(DATA_death));
	}

	@Override
	public void readAdditionalSaveData(ValueInput valueInput) {
		super.readAdditionalSaveData(valueInput);
		this.setTexture(valueInput.getStringOr("Texture", "snail_texture"));
		this.entityData.set(DATA_variant, valueInput.getIntOr("Datavariant", 0));
		this.entityData.set(DATA_hide, valueInput.getIntOr("Datahide", 0));
		this.entityData.set(DATA_tp, valueInput.getIntOr("Datatp", 0));
		this.entityData.set(DATA_immortality, valueInput.getIntOr("Dataimmortality", 0));
		this.entityData.set(DATA_death, valueInput.getIntOr("Datadeath", 0));
	}

	@Override
	public InteractionResult mobInteract(Player sourceentity, InteractionHand hand) {
		ItemStack itemstack = sourceentity.getItemInHand(hand);
		InteractionResult retval = InteractionResult.SUCCESS;
		super.mobInteract(sourceentity, hand);
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Entity entity = this;
		Level world = this.level();

		ImmortalSnailRightclickedOnEntityProcedure.execute(world, x, y, z, entity, itemstack);
		return retval;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(IdleSnailPlaybackConditionProcedure.execute(this), this.tickCount);
			this.animationState1.animateWhen(WalkSnailPlaybackConditionProcedure.execute(this), this.tickCount);
		}
	}

	@Override
	public void baseTick() {
		super.baseTick();
		ImmortalSnailOnEntityTickUpdateProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), this);
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.1);
		builder = builder.add(Attributes.MAX_HEALTH, 150);
		builder = builder.add(Attributes.ARMOR, 20);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 1);
		builder = builder.add(Attributes.FOLLOW_RANGE, 1032);
		builder = builder.add(Attributes.STEP_HEIGHT, 0.6);
		return builder;
	}
}