package net.mcreator.gastropodgalore.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class RoastedCarrotItem extends Item {
	public RoastedCarrotItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(5).saturationModifier(6f).build()));
	}
}