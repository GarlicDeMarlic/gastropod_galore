package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.MossySnailEntity;

public class RedMossySnailDisplayConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_variant) : 0) == 3;
	}
}