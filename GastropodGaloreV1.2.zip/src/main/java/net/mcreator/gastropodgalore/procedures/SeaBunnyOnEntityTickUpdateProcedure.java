package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;

import java.util.Comparator;

public class SeaBunnyOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livingEntity0 && _livingEntity0.getAttributes().hasAttribute(NeoForgeMod.SWIM_SPEED))
			_livingEntity0.getAttribute(NeoForgeMod.SWIM_SPEED).setBaseValue(3);
		if (!isInWaterRainOrBubble(entity)) {
			if (entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
				_livingEntity2.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.075);
			if (entity.getPersistentData().getDoubleOr("drown_timer", 0) >= 400) {
				entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 1);
				if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) == 10) {
					entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 1);
				} else {
					entity.getPersistentData().putDouble("additionaldrown_timer", (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) + 1));
				}
				if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) > 10) {
					if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) == 20) {
						entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 1);
					} else {
						entity.getPersistentData().putDouble("additionaldrown_timer", (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) + 1));
					}
				}
				if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) > 20) {
					if (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) == 30) {
						entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.DRY_OUT)), 10);
					} else {
						entity.getPersistentData().putDouble("additionaldrown_timer", (entity.getPersistentData().getDoubleOr("additionaldrown_timer", 0) + 1));
					}
				}
			} else {
				entity.getPersistentData().putDouble("drown_timer", (entity.getPersistentData().getDoubleOr("drown_timer", 0) + 1));
			}
		} else {
			entity.getPersistentData().putDouble("drown_timer", 0);
			entity.getPersistentData().putDouble("additionaldrown_timer", 0);
		}
		{
			final Vec3 _center = new Vec3((entity.getX()), (entity.getY()), (entity.getZ()));
			for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(10 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
				if (entityiterator instanceof Player || entityiterator instanceof ServerPlayer) {
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 120, 1));
				}
			}
		}
	}

	private static boolean isInWaterRainOrBubble(Entity entity) {
		return entity.isInWaterOrRain() || entity.getInBlockState().is(Blocks.BUBBLE_COLUMN);
	}
}