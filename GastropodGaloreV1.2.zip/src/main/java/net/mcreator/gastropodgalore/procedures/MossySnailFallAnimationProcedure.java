package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.entity.MossySnailEntity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class MossySnailFallAnimationProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((world.canSeeSkyFromBelowWater(BlockPos.containing(x, y, z)) || world.getMaxLocalRawBrightness(BlockPos.containing(x, y - 2, z)) < 13) && world.isEmptyBlock(BlockPos.containing(x, y, z))
				&& world.isEmptyBlock(BlockPos.containing(x, y - 1, z)) && world.isEmptyBlock(BlockPos.containing(x, y - 2, z)) && !entity.onGround() && entity instanceof MossySnailEntity) {
			if ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_hide) : 0) == 0) {
				if (entity instanceof MossySnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MossySnailEntity.DATA_hide_timer, 140);
				if (entity instanceof MossySnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MossySnailEntity.DATA_hide, 2);
				if (entity instanceof LivingEntity _livingEntity10 && _livingEntity10.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
					_livingEntity10.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0);
			}
		}
	}
}