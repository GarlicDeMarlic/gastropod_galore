package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.PaintedSnailEntity;

public class YellowPaintedSnailDisplayConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof PaintedSnailEntity _datEntI ? _datEntI.getEntityData().get(PaintedSnailEntity.DATA_variant) : 0) == 2;
	}
}