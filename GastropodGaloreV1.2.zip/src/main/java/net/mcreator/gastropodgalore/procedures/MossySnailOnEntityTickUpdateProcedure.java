package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.gastropodgalore.entity.SnailEntity;
import net.mcreator.gastropodgalore.entity.MossySnailEntity;

import java.util.Comparator;

public class MossySnailOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double posX = 0;
		double posY = 0;
		double posZ = 0;
		boolean found = false;
		Entity player = null;
		player = findEntityInWorldRange(world, Player.class, (entity.getX()), (entity.getY()), (entity.getZ()), 10);
		found = false;
		if (!((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:snail_food")))
				|| (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:snail_food")))) && entity.getPersistentData().getDoubleOr("Love", 0) == 0
				&& entity.getPersistentData().getDoubleOr("found", 0) == 0 && entity.getPersistentData().getDoubleOr("TargetX", 0) == 0 && entity.getPersistentData().getDoubleOr("TargetY", 0) == 0
				&& entity.getPersistentData().getDoubleOr("TargetZ", 0) == 0) {
			for (int index0 = 0; index0 < 40; index0++) {
				posX = x + 0.5 + Mth.nextDouble(RandomSource.create(), -12, 12);
				posY = y + Mth.nextDouble(RandomSource.create(), -5, 5);
				posZ = z + 0.5 + Mth.nextDouble(RandomSource.create(), -12, 12);
				if ((world.getBlockState(BlockPos.containing(posX, posY, posZ))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:crop"))) && !(entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
					entity.getPersistentData().putDouble("TargetX", posX);
					entity.getPersistentData().putDouble("TargetY", posY);
					entity.getPersistentData().putDouble("TargetZ", posZ);
					entity.getPersistentData().putDouble("found", 1);
					found = true;
					break;
				} else if ((world.getBlockState(BlockPos.containing(posX, posY, posZ))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:crop")))
						&& (((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0
								|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
										.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0)
						&& (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
					entity.getPersistentData().putDouble("TargetX", posX);
					entity.getPersistentData().putDouble("TargetY", posY);
					entity.getPersistentData().putDouble("TargetZ", posZ);
					entity.getPersistentData().putDouble("found", 1);
					found = true;
					break;
				}
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y + 1, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:crop")))) {
			if ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_eat_timer) : 0) == 40
					|| (entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_eat_timer) : 0) > 40) {
				if (!(entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) || (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)
						&& (((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0
								|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
										.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0)) {
					if (!(((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
							.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) > 1
							|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
									.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) > 1)) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 5, false, false));
					}
					entity.getPersistentData().putDouble("TargetX", 0);
					entity.getPersistentData().putDouble("TargetY", 0);
					entity.getPersistentData().putDouble("TargetZ", 0);
					found = false;
					if (entity instanceof MossySnailEntity _datEntSetI)
						_datEntSetI.getEntityData().set(MossySnailEntity.DATA_eat_timer, 0);
					if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
						if (Math.random() < 0.41) {
							if (world instanceof ServerLevel _level) {
								ItemEntity entityToSpawn = new ItemEntity(_level, x, (y + 0.5), z, new ItemStack(Items.SLIME_BALL));
								entityToSpawn.setPickUpDelay(10);
								_level.addFreshEntity(entityToSpawn);
							}
						}
						{
							BlockPos _pos = BlockPos.containing(x, y + 1, z);
							Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y + 0.5, z), null);
							world.destroyBlock(_pos, false);
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.5, 0.5, 0.5, 1);
					} else {
						if (!(entity instanceof LivingEntity _livEnt66 && _livEnt66.isBaby())) {
							if (Math.random() < 0.2) {
								if (Math.random() < 0.4) {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:1,Datababy:1}");
								} else if (Math.random() < 0.6) {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:1,Datababy:1}");
								} else if (Math.random() < 0.8) {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:2,Datababy:1}");
								} else {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:3,Datababy:1}");
								}
								{
									final Vec3 _center = new Vec3(x, y, z);
									for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
											.toList()) {
										if (entityiterator instanceof TamableAnimal _toTame && (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player _owner)
											_toTame.tame(_owner);
									}
								}
							}
						}
						world.destroyBlock(BlockPos.containing(x, y + 1, z), false);
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.5, 0.5, 0.5, 1);
					}
					entity.getPersistentData().putDouble("found", 0);
				}
			} else {
				if (entity instanceof MossySnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MossySnailEntity.DATA_eat_timer, (int) ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_eat_timer) : 0) + 1));
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:crop")))) {
			if ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_eat_timer) : 0) == 40
					|| (entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_eat_timer) : 0) > 40) {
				if (!(entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) || (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)
						&& (((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0
								|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
										.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0)) {
					if (!(((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
							.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) > 1
							|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
									.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) > 1)) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 5, false, false));
					}
					entity.getPersistentData().putDouble("TargetX", 0);
					entity.getPersistentData().putDouble("TargetY", 0);
					entity.getPersistentData().putDouble("TargetZ", 0);
					found = false;
					if (entity instanceof MossySnailEntity _datEntSetI)
						_datEntSetI.getEntityData().set(MossySnailEntity.DATA_eat_timer, 0);
					if (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) {
						if (Math.random() < 0.11) {
							if (world instanceof ServerLevel _level) {
								ItemEntity entityToSpawn = new ItemEntity(_level, x, (y + 0.5), z, new ItemStack(Items.SLIME_BALL));
								entityToSpawn.setPickUpDelay(10);
								_level.addFreshEntity(entityToSpawn);
							}
						}
						{
							BlockPos _pos = BlockPos.containing(x, y, z);
							Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y + 0.5, z), null);
							world.destroyBlock(_pos, false);
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.5, 0.5, 0.5, 1);
					} else {
						if (!(entity instanceof LivingEntity _livEnt112 && _livEnt112.isBaby())) {
							if (Math.random() < 0.2) {
								if (Math.random() < 0.4) {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:1,Datababy:1}");
								} else if (Math.random() < 0.6) {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:1,Datababy:1}");
								} else if (Math.random() < 0.8) {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:2,Datababy:1}");
								} else {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"summon gastropod_galore:mossy_snail ~ ~ ~ {Age:-25000,Datavariant:3,Datababy:1}");
								}
								{
									final Vec3 _center = new Vec3(x, y, z);
									for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
											.toList()) {
										if (entityiterator instanceof TamableAnimal _toTame && (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player _owner)
											_toTame.tame(_owner);
									}
								}
							}
						}
						world.destroyBlock(BlockPos.containing(x, y, z), false);
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.5, 0.5, 0.5, 1);
					}
					entity.getPersistentData().putDouble("found", 0);
				}
			} else {
				if (entity instanceof MossySnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MossySnailEntity.DATA_eat_timer, (int) ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_eat_timer) : 0) + 1));
			}
		}
		if (!(world.getBlockState(BlockPos.containing(entity.getPersistentData().getDoubleOr("TargetX", 0), entity.getPersistentData().getDoubleOr("TargetY", 0), entity.getPersistentData().getDoubleOr("TargetZ", 0))))
				.is(BlockTags.create(ResourceLocation.parse("gastropod_galore:crop")))) {
			entity.getPersistentData().putDouble("TargetX", 0);
			entity.getPersistentData().putDouble("TargetY", 0);
			entity.getPersistentData().putDouble("TargetZ", 0);
			entity.getPersistentData().putDouble("found", 0);
		}
		if (entity.getPersistentData().getDoubleOr("found", 0) == 1 && !((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:snail_food")))
				|| (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:snail_food"))))) {
			if (entity instanceof Mob _entity)
				_entity.getNavigation().moveTo((entity.getPersistentData().getDoubleOr("TargetX", 0)), (entity.getPersistentData().getDoubleOr("TargetY", 0) + 1), (entity.getPersistentData().getDoubleOr("TargetZ", 0)), 1);
		}
		if (entity.getPersistentData().getDoubleOr("found", 0) == 1 && ((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:snail_food")))
				|| (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:snail_food"))))) {
			entity.getPersistentData().putDouble("TargetX", 0);
			entity.getPersistentData().putDouble("TargetY", 0);
			entity.getPersistentData().putDouble("TargetZ", 0);
			entity.getPersistentData().putDouble("found", 0);
			if (entity instanceof Mob _entity)
				_entity.getNavigation().stop();
		}
		if (entity.getPersistentData().getDoubleOr("snail_trail", 0) == 300 || entity.getPersistentData().getDoubleOr("snail_trail", 0) > 300) {
			if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == Blocks.FARMLAND) {
				if (Math.random() < 0.4) {
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.5, 0.5, 0.5, 1);
					if (world instanceof Level _level) {
						BlockPos _bp = BlockPos.containing(x, y, z);
						if (BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), _level, _bp) || BoneMealItem.growWaterPlant(new ItemStack(Items.BONE_MEAL), _level, _bp, null)) {
							if (!_level.isClientSide())
								_level.levelEvent(2005, _bp, 0);
						}
					}
					entity.getPersistentData().putDouble("snail_trail", 0);
				}
			}
		} else {
			entity.getPersistentData().putDouble("snail_trail", (entity.getPersistentData().getDoubleOr("snail_trail", 0) + 1));
		}
		if (entity.getPersistentData().getDoubleOr("Love", 0) > 0) {
			entity.getPersistentData().putDouble("Love", (entity.getPersistentData().getDoubleOr("Love", 0) - 1));
		}
		if ((entity instanceof SnailEntity _datEntI ? _datEntI.getEntityData().get(SnailEntity.DATA_breed_cooldown) : 0) > 0) {
			if (entity instanceof MossySnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MossySnailEntity.DATA_breed_cooldown, (int) ((entity instanceof SnailEntity _datEntI ? _datEntI.getEntityData().get(SnailEntity.DATA_breed_cooldown) : 0) - 1));
		}
		if (entity instanceof MossySnailEntity) {
			if ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_hide_timer) : 0) > 0) {
				if (entity instanceof MossySnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MossySnailEntity.DATA_hide_timer, (int) ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_hide_timer) : 0) - 1));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 1, 255, false, false));
				if ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_hide_timer) : 0) > 20) {
					if (entity instanceof MossySnailEntity _datEntSetI)
						_datEntSetI.getEntityData().set(MossySnailEntity.DATA_hide, 2);
				} else if ((entity instanceof MossySnailEntity _datEntI ? _datEntI.getEntityData().get(MossySnailEntity.DATA_hide_timer) : 0) <= 20) {
					if (entity instanceof MossySnailEntity _datEntSetI)
						_datEntSetI.getEntityData().set(MossySnailEntity.DATA_hide, 1);
				}
			} else {
				if (entity instanceof MossySnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(MossySnailEntity.DATA_hide, 0);
				if (!(((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
						.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) != 0
						|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) != 0)) {
					if (entity instanceof LivingEntity _livingEntity190 && _livingEntity190.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
						_livingEntity190.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.1);
				}
			}
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}