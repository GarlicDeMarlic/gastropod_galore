package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

public class BobSnailDisplayConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity.getDisplayName().getString()).equals("Bob");
	}
}