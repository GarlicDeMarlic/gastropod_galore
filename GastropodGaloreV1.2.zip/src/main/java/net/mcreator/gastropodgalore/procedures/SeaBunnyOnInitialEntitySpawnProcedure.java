package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.gastropodgalore.entity.SeaBunnyEntity;

import java.util.Comparator;

public class SeaBunnyOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("croppy", 0);
		if (!(entity instanceof LivingEntity _livEnt1 && _livEnt1.isBaby())) {
			if (Mth.nextInt(RandomSource.create(), 1, 100) < 30) {
				if (entity instanceof SeaBunnyEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 0);
			} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 55) {
				if (entity instanceof SeaBunnyEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 1);
			} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 75) {
				if (entity instanceof SeaBunnyEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 2);
			} else {
				if (entity instanceof SeaBunnyEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 3);
			}
		} else {
			{
				final Vec3 _center = new Vec3((entity.getX()), (entity.getY()), (entity.getZ()));
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof SeaBunnyEntity && entity instanceof LivingEntity _livEnt13 && _livEnt13.isBaby()) {
						if (entity instanceof SeaBunnyEntity _datEntSetI)
							_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, (int) (entityiterator instanceof SeaBunnyEntity _datEntI ? _datEntI.getEntityData().get(SeaBunnyEntity.DATA_variant) : 0));
					} else if (!(entityiterator instanceof SeaBunnyEntity) && entity instanceof LivingEntity _livEnt17 && _livEnt17.isBaby()) {
						if (Mth.nextInt(RandomSource.create(), 1, 100) < 30) {
							if (entity instanceof SeaBunnyEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 0);
						} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 55) {
							if (entity instanceof SeaBunnyEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 1);
						} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 75) {
							if (entity instanceof SeaBunnyEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 2);
						} else {
							if (entity instanceof SeaBunnyEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SeaBunnyEntity.DATA_variant, 3);
						}
					}
				}
			}
		}
	}
}