package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.AppleSnailEntity;

public class AppleSnailEntityIsHurtProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof AppleSnailEntity _datEntSetI)
			_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_hide_timer, 140);
		if (entity instanceof AppleSnailEntity _datEntSetI)
			_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_hide, 2);
		if (entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
			_livingEntity2.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0);
	}
}