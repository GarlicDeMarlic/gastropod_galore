package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

import net.mcreator.gastropodgalore.init.GastropodGaloreModBlocks;

import java.util.List;

public class GardenSnailTerrariumSpecialInformationProcedure {
	public static void execute(ItemStack itemstack, List<Component> tooltip) {
		if (tooltip == null)
			return;
		if (itemstack.getItem() == GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM_1.get().asItem()) {
			tooltip.add(Component.literal("Snail: Green"));
		} else if (itemstack.getItem() == GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM_2.get().asItem()) {
			tooltip.add(Component.literal("Snail: Yellow"));
		} else if (itemstack.getItem() == GastropodGaloreModBlocks.GARDEN_SNAIL_TERRARIUM_3.get().asItem()) {
			tooltip.add(Component.literal("Snail: Red"));
		} else {
			tooltip.add(Component.literal("Snail: Brown"));
		}
	}
}