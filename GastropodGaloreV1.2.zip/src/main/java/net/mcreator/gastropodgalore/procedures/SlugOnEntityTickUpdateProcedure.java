package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.gastropodgalore.entity.SlugEntity;
import net.mcreator.gastropodgalore.entity.BananaSlugEntity;

import java.util.Comparator;

public class SlugOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean found = false;
		Entity player = null;
		BlockState crop = Blocks.AIR.defaultBlockState();
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double posX = 0;
		double posY = 0;
		double posZ = 0;
		double crop_seed = 0;
		player = findEntityInWorldRange(world, Player.class, (entity.getX()), (entity.getY()), (entity.getZ()), 10);
		found = false;
		if (!((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food")))
				|| (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food")))) && entity.getPersistentData().getDoubleOr("Love", 0) == 0
				&& entity.getPersistentData().getDoubleOr("found", 0) == 0 && entity.getPersistentData().getDoubleOr("TargetX", 0) == 0 && entity.getPersistentData().getDoubleOr("TargetY", 0) == 0
				&& entity.getPersistentData().getDoubleOr("TargetZ", 0) == 0) {
			for (int index0 = 0; index0 < 40; index0++) {
				posX = x + 0.5 + Mth.nextDouble(RandomSource.create(), -12, 12);
				posY = y + Mth.nextDouble(RandomSource.create(), -5, 5);
				posZ = z + 0.5 + Mth.nextDouble(RandomSource.create(), -12, 12);
				if ((world.getBlockState(BlockPos.containing(posX, posY, posZ))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:grass")))
						&& (((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0
								|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
										.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0)) {
					entity.getPersistentData().putDouble("TargetX", posX);
					entity.getPersistentData().putDouble("TargetY", posY);
					entity.getPersistentData().putDouble("TargetZ", posZ);
					entity.getPersistentData().putDouble("found", 1);
					found = true;
					break;
				}
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:grass")))
				&& (((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
						.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0
						|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:cultivation")))) != 0)) {
			if ((entity instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_eat_timer) : 0) == 40 || (entity instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_eat_timer) : 0) > 40) {
				if (!(((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
						.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) > 1
						|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
								.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) > 1)) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 5, false, false));
				}
				entity.getPersistentData().putDouble("TargetX", 0);
				entity.getPersistentData().putDouble("TargetY", 0);
				entity.getPersistentData().putDouble("TargetZ", 0);
				found = false;
				if (entity instanceof SlugEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SlugEntity.DATA_eat_timer, 0);
				if (Math.random() < 0.05) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Items.SLIME_BALL));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				}
				if (!(entity instanceof LivingEntity _livEnt50 && _livEnt50.isBaby())) {
					if (Math.random() < 0.15) {
						if (entity instanceof SlugEntity) {
							if (world instanceof ServerLevel _level)
								_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
										"summon gastropod_galore:slug ~ ~ ~ {Age:-25000}");
							{
								final Vec3 _center = new Vec3(x, y, z);
								for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
										.toList()) {
									if (entityiterator instanceof SlugEntity && entityiterator instanceof LivingEntity _livEnt54 && _livEnt54.isBaby()) {
										if (Mth.nextInt(RandomSource.create(), 1, 100) < 30) {
											if (entityiterator instanceof SlugEntity _datEntSetI)
												_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 0);
										} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 55) {
											if (entityiterator instanceof SlugEntity _datEntSetI)
												_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 1);
										} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 75) {
											if (entityiterator instanceof SlugEntity _datEntSetI)
												_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 2);
										} else {
											if (entityiterator instanceof SlugEntity _datEntSetI)
												_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 3);
										}
									}
									if (entityiterator instanceof TamableAnimal _toTame && (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player _owner)
										_toTame.tame(_owner);
								}
							}
						} else if (entity instanceof BananaSlugEntity) {
							if (world instanceof ServerLevel _level)
								_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
										"summon gastropod_galore:banana_slug ~ ~ ~ {Age:-25000}");
						}
					}
				}
				world.destroyBlock(BlockPos.containing(x, y, z), false);
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.3, 0.3, 0.3, 1);
				entity.getPersistentData().putDouble("found", 0);
			} else {
				if (entity instanceof SlugEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SlugEntity.DATA_eat_timer, (int) ((entity instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_eat_timer) : 0) + 1));
			}
		}
		if (!(world.getBlockState(BlockPos.containing(entity.getPersistentData().getDoubleOr("TargetX", 0), entity.getPersistentData().getDoubleOr("TargetY", 0), entity.getPersistentData().getDoubleOr("TargetZ", 0))))
				.is(BlockTags.create(ResourceLocation.parse("gastropod_galore:grass")))) {
			entity.getPersistentData().putDouble("TargetX", 0);
			entity.getPersistentData().putDouble("TargetY", 0);
			entity.getPersistentData().putDouble("TargetZ", 0);
			entity.getPersistentData().putDouble("found", 0);
			found = false;
		}
		if (entity.getPersistentData().getDoubleOr("found", 0) == 1 && !((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food")))
				|| (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food"))))) {
			if (entity instanceof Mob _entity)
				_entity.getNavigation().moveTo((entity.getPersistentData().getDoubleOr("TargetX", 0)), (entity.getPersistentData().getDoubleOr("TargetY", 0) + 1), (entity.getPersistentData().getDoubleOr("TargetZ", 0)), 1);
		}
		if (entity.getPersistentData().getDoubleOr("found", 0) == 1 && ((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food")))
				|| (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:slug_food"))))) {
			entity.getPersistentData().putDouble("TargetX", 0);
			entity.getPersistentData().putDouble("TargetY", 0);
			entity.getPersistentData().putDouble("TargetZ", 0);
			entity.getPersistentData().putDouble("found", 0);
			if (entity instanceof Mob _entity)
				_entity.getNavigation().stop();
		}
		if (entity.getPersistentData().getDoubleOr("Love", 0) > 0) {
			entity.getPersistentData().putDouble("Love", (entity.getPersistentData().getDoubleOr("Love", 0) - 1));
		}
		if ((entity instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_breed_cooldown) : 0) > 0) {
			if (entity instanceof SlugEntity _datEntSetI)
				_datEntSetI.getEntityData().set(SlugEntity.DATA_breed_cooldown, (int) ((entity instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_breed_cooldown) : 0) - 1));
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}