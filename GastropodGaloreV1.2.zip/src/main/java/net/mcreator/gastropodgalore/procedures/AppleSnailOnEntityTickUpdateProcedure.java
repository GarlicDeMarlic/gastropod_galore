package net.mcreator.gastropodgalore.procedures;

import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.gastropodgalore.entity.AppleSnailEntity;

import java.util.Comparator;

public class AppleSnailOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean found = false;
		Entity player = null;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double posX = 0;
		double posY = 0;
		double posZ = 0;
		player = findEntityInWorldRange(world, Player.class, (entity.getX()), (entity.getY()), (entity.getZ()), 10);
		found = false;
		if (entity.getPersistentData().getDoubleOr("found", 0) == 0) {
			for (int index0 = 0; index0 < 40; index0++) {
				posX = x + 0.5 + Mth.nextDouble(RandomSource.create(), -8, 8);
				posY = y + Mth.nextDouble(RandomSource.create(), -2, 2);
				posZ = z + 0.5 + Mth.nextDouble(RandomSource.create(), -8, 8);
				if ((world.getBlockState(BlockPos.containing(posX, posY, posZ))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:sea_plants")))) {
					entity.getPersistentData().putDouble("TargetX", posX);
					entity.getPersistentData().putDouble("TargetY", posY);
					entity.getPersistentData().putDouble("TargetZ", posZ);
					entity.getPersistentData().putDouble("found", 1);
					found = true;
					break;
				}
			}
		}
		if (entity.getPersistentData().getDoubleOr("found", 0) == 1 && !((player instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:sea_food")))
				&& (player instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("gastropod_galore:sea_food"))))) {
			if (entity instanceof Mob _entity)
				_entity.getNavigation().moveTo((entity.getPersistentData().getDoubleOr("TargetX", 0)), (entity.getPersistentData().getDoubleOr("TargetY", 0) + 1), (entity.getPersistentData().getDoubleOr("TargetZ", 0)), 1);
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).is(BlockTags.create(ResourceLocation.parse("gastropod_galore:sea_plants")))) {
			if ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_eat_timer) : 0) == 30
					|| (entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_eat_timer) : 0) > 30) {
				if (!(entity instanceof LivingEntity _livEnt27 && _livEnt27.isBaby())) {
					if (Math.random() < 0.3) {
						if (world instanceof ServerLevel _level)
							_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
									"summon gastropod_galore:apple_snail ~ ~ ~ {Age:-25000}");
					}
				}
				entity.getPersistentData().putDouble("TargetX", 0);
				entity.getPersistentData().putDouble("TargetY", 0);
				entity.getPersistentData().putDouble("TargetZ", 0);
				found = false;
				if (entity instanceof AppleSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_eat_timer, 0);
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, (entity.getX()), (entity.getY()), (entity.getZ()), 5, 0.3, 0.3, 0.3, 1);
				world.destroyBlock(BlockPos.containing(x, y, z), false);
				if ((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Blocks.TALL_SEAGRASS) {
					world.destroyBlock(BlockPos.containing(x, y + 1, z), false);
				}
				entity.getPersistentData().putDouble("found", 0);
				if (entity instanceof Mob _entity)
					_entity.getNavigation().stop();
			} else {
				if (entity instanceof AppleSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_eat_timer, (int) ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_eat_timer) : 0) + 1));
			}
		}
		if ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_hide) : 0) > 0) {
			if (entity instanceof LivingEntity _livingEntity46 && _livingEntity46.getAttributes().hasAttribute(NeoForgeMod.SWIM_SPEED))
				_livingEntity46.getAttribute(NeoForgeMod.SWIM_SPEED).setBaseValue(0);
		} else {
			if (entity instanceof LivingEntity _livingEntity47 && _livingEntity47.getAttributes().hasAttribute(NeoForgeMod.SWIM_SPEED))
				_livingEntity47.getAttribute(NeoForgeMod.SWIM_SPEED).setBaseValue(3);
		}
		if ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_hide_timer) : 0) > 0) {
			if (entity instanceof AppleSnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_hide_timer, (int) ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_hide_timer) : 0) - 1));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 1, 255, false, false));
			if ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_hide_timer) : 0) > 20) {
				if (entity instanceof AppleSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_hide, 2);
			} else if ((entity instanceof AppleSnailEntity _datEntI ? _datEntI.getEntityData().get(AppleSnailEntity.DATA_hide_timer) : 0) <= 20) {
				if (entity instanceof AppleSnailEntity _datEntSetI)
					_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_hide, 1);
			}
		} else {
			if (entity instanceof AppleSnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(AppleSnailEntity.DATA_hide, 0);
			if (!(((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
					.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) != 0
					|| ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)
							.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("gastropod_galore:zeal")))) != 0)) {
				if (entity instanceof LivingEntity _livingEntity63 && _livingEntity63.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED))
					_livingEntity63.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.1);
			}
		}
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}
}