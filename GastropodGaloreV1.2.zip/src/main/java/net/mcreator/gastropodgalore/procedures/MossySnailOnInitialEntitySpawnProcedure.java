package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.MossySnailEntity;

public class MossySnailOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.isBaby()) {
			if (entity instanceof MossySnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MossySnailEntity.DATA_baby, 1);
		}
		if (Math.random() < 0.4) {
			if (entity instanceof MossySnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MossySnailEntity.DATA_variant, 0);
		} else if (Math.random() < 0.6) {
			if (entity instanceof MossySnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MossySnailEntity.DATA_variant, 1);
		} else if (Math.random() < 0.8) {
			if (entity instanceof MossySnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MossySnailEntity.DATA_variant, 2);
		} else {
			if (entity instanceof MossySnailEntity _datEntSetI)
				_datEntSetI.getEntityData().set(MossySnailEntity.DATA_variant, 3);
		}
	}
}