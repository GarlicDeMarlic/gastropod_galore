package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

public class PaintedSnailRightclickedOnEntityProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, ItemStack itemstack) {
		double X = 0;
		double Y = 0;
		double Z = 0;
		double RandomNumber = 0;
		X = x;
		Y = y;
		Z = z;
		RandomNumber = Mth.nextDouble(RandomSource.create(), 2, 4);
		if (itemstack.getItem() == Blocks.POPPY.asItem() || itemstack.getItem() == Items.BEETROOT || itemstack.getItem() == Blocks.RED_TULIP.asItem() || itemstack.getItem() == Blocks.ROSE_BUSH.asItem()) {
			if (itemstack.getItem() == Blocks.ROSE_BUSH.asItem()) {
				RandomNumber = Mth.nextDouble(RandomSource.create(), 4, 8);
			}
			for (int index0 = 0; index0 < (int) RandomNumber; index0++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.RED_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.CORNFLOWER.asItem()) {
			for (int index1 = 0; index1 < (int) RandomNumber; index1++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.BLUE_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.DANDELION.asItem() || itemstack.getItem() == Blocks.SUNFLOWER.asItem() || itemstack.getItem() == Blocks.WILDFLOWERS.asItem()) {
			if (itemstack.getItem() == Blocks.SUNFLOWER.asItem()) {
				RandomNumber = Mth.nextDouble(RandomSource.create(), 4, 8);
			}
			for (int index2 = 0; index2 < (int) RandomNumber; index2++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.YELLOW_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.TORCHFLOWER.asItem() || itemstack.getItem() == Blocks.OPEN_EYEBLOSSOM.asItem() || itemstack.getItem() == Blocks.ORANGE_TULIP.asItem()) {
			for (int index3 = 0; index3 < (int) RandomNumber; index3++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.ORANGE_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.PITCHER_PLANT.asItem()) {
			RandomNumber = Mth.nextDouble(RandomSource.create(), 4, 8);
			for (int index4 = 0; index4 < (int) RandomNumber; index4++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.CYAN_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.BLUE_ORCHID.asItem()) {
			for (int index5 = 0; index5 < (int) RandomNumber; index5++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.LIGHT_BLUE_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.CACTUS_FLOWER.asItem() || itemstack.getItem() == Blocks.PEONY.asItem() || itemstack.getItem() == Blocks.PINK_TULIP.asItem() || itemstack.getItem() == Blocks.PINK_PETALS.asItem()) {
			if (itemstack.getItem() == Blocks.PEONY.asItem()) {
				RandomNumber = Mth.nextDouble(RandomSource.create(), 4, 8);
			}
			for (int index6 = 0; index6 < (int) RandomNumber; index6++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.PINK_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.ALLIUM.asItem() || itemstack.getItem() == Blocks.LILAC.asItem()) {
			if (itemstack.getItem() == Blocks.LILAC.asItem()) {
				RandomNumber = Mth.nextDouble(RandomSource.create(), 4, 8);
			}
			for (int index7 = 0; index7 < (int) RandomNumber; index7++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.MAGENTA_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.LILY_OF_THE_VALLEY.asItem() || itemstack.getItem() == Items.BONE_MEAL) {
			for (int index8 = 0; index8 < (int) RandomNumber; index8++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.WHITE_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.WHITE_TULIP.asItem() || itemstack.getItem() == Blocks.AZURE_BLUET.asItem() || itemstack.getItem() == Blocks.OXEYE_DAISY.asItem()) {
			for (int index9 = 0; index9 < (int) RandomNumber; index9++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.LIGHT_GRAY_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Blocks.CLOSED_EYEBLOSSOM.asItem()) {
			for (int index10 = 0; index10 < (int) RandomNumber; index10++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.GRAY_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		} else if (itemstack.getItem() == Items.COCOA_BEANS) {
			for (int index11 = 0; index11 < (int) RandomNumber; index11++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, X, Y, Z, new ItemStack(Items.BROWN_DYE));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			itemstack.setCount(itemstack.getCount() - 1);
		}
	}
}