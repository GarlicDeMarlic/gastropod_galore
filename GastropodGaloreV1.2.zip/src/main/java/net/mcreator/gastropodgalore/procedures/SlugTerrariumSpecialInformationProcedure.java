package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

import net.mcreator.gastropodgalore.init.GastropodGaloreModBlocks;

import java.util.List;

public class SlugTerrariumSpecialInformationProcedure {
	public static void execute(ItemStack itemstack, List<Component> tooltip) {
		if (tooltip == null)
			return;
		if (itemstack.getItem() == GastropodGaloreModBlocks.SLUG_TERRARIUM_1.get().asItem()) {
			tooltip.add(Component.literal("Slug: Red"));
		} else if (itemstack.getItem() == GastropodGaloreModBlocks.SLUG_TERRARIUM_2.get().asItem()) {
			tooltip.add(Component.literal("Slug: Black"));
		} else if (itemstack.getItem() == GastropodGaloreModBlocks.SLUG_TERRARIUM_3.get().asItem()) {
			tooltip.add(Component.literal("Slug: Green"));
		} else {
			tooltip.add(Component.literal("Slug: Tan"));
		}
	}
}