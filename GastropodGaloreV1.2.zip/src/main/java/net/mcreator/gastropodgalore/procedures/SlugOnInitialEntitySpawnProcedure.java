package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.gastropodgalore.entity.SlugEntity;

import java.util.Comparator;

public class SlugOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putBoolean("connection", false);
		if (!(entity instanceof LivingEntity _livEnt1 && _livEnt1.isBaby())) {
			if (Mth.nextInt(RandomSource.create(), 1, 100) < 30) {
				if (entity instanceof SlugEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 0);
			} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 55) {
				if (entity instanceof SlugEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 1);
			} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 75) {
				if (entity instanceof SlugEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 2);
			} else {
				if (entity instanceof SlugEntity _datEntSetI)
					_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 3);
			}
		} else {
			{
				final Vec3 _center = new Vec3((entity.getX()), (entity.getY()), (entity.getZ()));
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof SlugEntity && entity instanceof LivingEntity _livEnt13 && _livEnt13.isBaby()) {
						if (entity instanceof SlugEntity _datEntSetI)
							_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, (int) (entityiterator instanceof SlugEntity _datEntI ? _datEntI.getEntityData().get(SlugEntity.DATA_variant) : 0));
						if (entity instanceof TamableAnimal _toTame && (entityiterator instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof Player _owner)
							_toTame.tame(_owner);
					} else if (!(entityiterator instanceof SlugEntity) && entity instanceof LivingEntity _livEnt19 && _livEnt19.isBaby()) {
						if (Mth.nextInt(RandomSource.create(), 1, 100) < 30) {
							if (entity instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 0);
						} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 55) {
							if (entity instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 1);
						} else if (Mth.nextInt(RandomSource.create(), 1, 100) < 75) {
							if (entity instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 2);
						} else {
							if (entity instanceof SlugEntity _datEntSetI)
								_datEntSetI.getEntityData().set(SlugEntity.DATA_variant, 3);
						}
					}
				}
			}
		}
	}
}