package net.mcreator.gastropodgalore.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gastropodgalore.entity.VolcanicSnailEntity;

public class VolcanicSnailDisplayConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof VolcanicSnailEntity _datEntI ? _datEntI.getEntityData().get(VolcanicSnailEntity.DATA_lava_cracks) : 0) == 1;
	}
}