package net.mcreator.gastropodgalore.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.gastropodgalore.procedures.GardenSnailTerrariumOnBlockRightclickedProcedure;
import net.mcreator.gastropodgalore.procedures.GardenSnailTerrariumBlockIsPlacedByProcedure;

public class GardenSnailTerrarium1Block extends Block {
	public static final IntegerProperty BLOCKSTATE = IntegerProperty.create("blockstate", 0, 1);
	public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;

	public GardenSnailTerrarium1Block(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GLASS).strength(1f, 10f).lightLevel(s -> (new Object() {
			public int getLightLevel() {
				if (s.getValue(BLOCKSTATE) == 1)
					return 0;
				return 0;
			}
		}.getLightLevel())).noOcclusion().pushReaction(PushReaction.PUSH_ONLY).isRedstoneConductor((bs, br, bp) -> false).dynamicShape());
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		if (state.getValue(BLOCKSTATE) == 1) {
			return switch (state.getValue(FACING)) {
				default -> Shapes.or(box(1, 0, 1, 15, 13, 1.1), box(1, 0, 14.9, 15, 13, 15), box(1.001, 12.9, 1.001, 15, 13, 15), box(1.001, 0, 1.001, 15, 0.1, 15), box(1, 0, 1, 1.1, 13, 15), box(14.9, 0, 1, 15, 13, 15), box(2, 13, 2, 14, 15, 14),
						box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
				case NORTH -> Shapes.or(box(1, 0, 14.9, 15, 13, 15), box(1, 0, 1, 15, 13, 1.1), box(1, 12.9, 1, 14.999, 13, 14.999), box(1, 0, 1, 14.999, 0.1, 14.999), box(14.9, 0, 1, 15, 13, 15), box(1, 0, 1, 1.1, 13, 15), box(2, 13, 2, 14, 15, 14),
						box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
				case EAST -> Shapes.or(box(1, 0, 1, 1.1, 13, 15), box(14.9, 0, 1, 15, 13, 15), box(1.001, 12.9, 1, 15, 13, 14.999), box(1.001, 0, 1, 15, 0.1, 14.999), box(1, 0, 14.9, 15, 13, 15), box(1, 0, 1, 15, 13, 1.1), box(2, 13, 2, 14, 15, 14),
						box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
				case WEST -> Shapes.or(box(14.9, 0, 1, 15, 13, 15), box(1, 0, 1, 1.1, 13, 15), box(1, 12.9, 1.001, 14.999, 13, 15), box(1, 0, 1.001, 14.999, 0.1, 15), box(1, 0, 1, 15, 13, 1.1), box(1, 0, 14.9, 15, 13, 15), box(2, 13, 2, 14, 15, 14),
						box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
			};
		}
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(1, 0, 1, 15, 13, 1.1), box(1, 0, 14.9, 15, 13, 15), box(1.001, 12.9, 1.001, 15, 13, 15), box(1.001, 0, 1.001, 15, 0.1, 15), box(1, 0, 1, 1.1, 13, 15), box(14.9, 0, 1, 15, 13, 15), box(2, 13, 2, 14, 15, 14),
					box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
			case NORTH -> Shapes.or(box(1, 0, 14.9, 15, 13, 15), box(1, 0, 1, 15, 13, 1.1), box(1, 12.9, 1, 14.999, 13, 14.999), box(1, 0, 1, 14.999, 0.1, 14.999), box(14.9, 0, 1, 15, 13, 15), box(1, 0, 1, 1.1, 13, 15), box(2, 13, 2, 14, 15, 14),
					box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
			case EAST -> Shapes.or(box(1, 0, 1, 1.1, 13, 15), box(14.9, 0, 1, 15, 13, 15), box(1.001, 12.9, 1, 15, 13, 14.999), box(1.001, 0, 1, 15, 0.1, 14.999), box(1, 0, 14.9, 15, 13, 15), box(1, 0, 1, 15, 13, 1.1), box(2, 13, 2, 14, 15, 14),
					box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
			case WEST -> Shapes.or(box(14.9, 0, 1, 15, 13, 15), box(1, 0, 1, 1.1, 13, 15), box(1, 12.9, 1.001, 14.999, 13, 15), box(1, 0, 1.001, 14.999, 0.1, 15), box(1, 0, 1, 15, 13, 1.1), box(1, 0, 14.9, 15, 13, 15), box(2, 13, 2, 14, 15, 14),
					box(2.5, 13, 2.5, 13.5, 14.9, 13.5), box(1, 14.6, 1, 15, 16, 15), box(1.1, 0.1, 1.1, 14.9, 2.1, 14.9));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, BLOCKSTATE);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public void setPlacedBy(Level world, BlockPos pos, BlockState blockstate, LivingEntity entity, ItemStack itemstack) {
		super.setPlacedBy(world, pos, blockstate, entity, itemstack);
		GardenSnailTerrariumBlockIsPlacedByProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public InteractionResult useWithoutItem(BlockState blockstate, Level world, BlockPos pos, Player entity, BlockHitResult hit) {
		super.useWithoutItem(blockstate, world, pos, entity, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		GardenSnailTerrariumOnBlockRightclickedProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}